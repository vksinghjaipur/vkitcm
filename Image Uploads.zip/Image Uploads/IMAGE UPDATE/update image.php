<?


public function update(Request $request ,$id=null)
    {
        // echo '<pre>'; print_r($request->all());exit;
        $servicetype= array();
        $servicetype['service_name']=$request->service_name;
       
       
        if(!empty($servicetype['service_image'])){
        $servicetype['service_image']=$servicetype['service_image'];
        $avatar = $servicetype['service_image'];
        $fileName = time().$avatar->getClientOriginalName();

        $destinationPath = public_path('/img/service-icon/');
        $avatar->move($destinationPath, $fileName);
        $servicetype = array_merge($servicetype, ['service_image' => $fileName]);
        
        }else{
            unset($servicetype['service_image']);
        } 
        DB::table('services')->where('id',$id)->update($servicetype);

        return new RedirectResponse(route('backend.services'), ['message' => __('The Service successfully updated.')]);
    }