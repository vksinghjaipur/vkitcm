<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\MultirowImage;
use DB;

class MultirowImageController extends Controller
{
    
    public function index(){

        $alldata = MultirowImage::get();
        //dd($alldata);
        return view('multirowimages.index',compact('alldata'));
    }


    public function create(){

        return view('multirowimages.create');
    }

    public function store(Request $request){

        $myname = $request->imgname;      
        if($request->hasFile('mutirowimg'))
        {     
            foreach($request->file('mutirowimg') as $file)
            {
                $image = rand(111,999).'.'.$file->extension();
                $file->move(public_path().'/multirowimages/', $image); 
                $file1 = array('imgname'=>$myname,'mutirowimg' => $image);
                DB::table('multirowimages')->insert($file1);
            }
        }

        return view('multirowimages.index');
    }


    public function edit($id=null, $imgname=null)
    {
        $alldata= MultirowImage::where('id',$id)->first();
        $data= MultirowImage::where('imgname',$imgname)->first();
        
        return view('multirowimages.edit', compact('alldata','data'));
    }
    
}
