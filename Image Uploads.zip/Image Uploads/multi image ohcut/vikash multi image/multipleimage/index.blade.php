<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

        <title>Multiple Image File Upload in Laravel</title>

    <body>
    
        <div class="container">
          <h2><center><u>MULTIPLE IMAGE UPLOAD IN LARAVEL</u></center></h2>
          <br>
          <h3><a href="{{'/'}}">Home</a></h3>
          <br> 
          <h4 class=""><a href="{{route('multiple-image.create')}}">Add Multiple Images</a></h4>
          
          <h3><center>Student List</center></h3> 
       

            <div class="col-xl-12 col-lg-12">
                <div class="card">
                  <div class="card-body">
                    <div class="table-responsive">
                      <table id="datatable-buttons" class="table table-bordered table-centered mb-0">
                        <thead>
                          <tr>
                            <th>Sr. No.</th>
                            <th>Image Name</th>
                            <th>Images</th>
                            <th class="text-center">Action</th>
                          </tr>
                        </thead>
                        
                        @foreach($data as $mydata) 
                        <tbody>
                          <tr>  
                            <td>{{$loop->iteration}}</td>
                            <td><a href="">{{$mydata->name}}</a></td>
                            
                            <td><?php foreach(json_decode($mydata->photo)as $myphoto) {?>
                              <img src="{{asset('mimages/'.$myphoto)}}" class="img-thumbnail" width="100" height="100">
                              <?php } ?>

                            </td>
                            
                            <td class="table-action text-center">                              
                              <a class="btn btn-primary" href="#">Edit</a>                            
                              <a class="btn btn-danger" href="#">Delete</a>
                            </td>
                          </tr>
                        </tbody>
                        @endforeach
                      </table>
                    </div>
                  </div>
                </div>
            </div>
        </div>
           
        
       
    </body>
</html>
