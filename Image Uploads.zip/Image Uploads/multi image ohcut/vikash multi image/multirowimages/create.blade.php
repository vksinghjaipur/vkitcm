<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

        <title>Multiple Image File Upload Multiple Row and Id</title>

    <body>
    
        <div class="container">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="page-title-right" style="display: block"> 
            <br>
            <a href="{{'/'}}"><h4 class="page-title">Home</h4></a>
            <br>
            <a href="" class="btn btn-outline-secondary btn-rounded"><span class="uil uil-users-alt"></span> All Multiple Image Upload in Multiple Row and ID</a> 
          </div>
           <br>
          <h4 class="page-title">Add Multiple Image..</h4>
          <br>
        </div>
      </div>
      <div class="col-xl-12 col-lg-12">
        <div class="card">
          <div class="card-body  pb-5">
            
            

            <form  method="POST" action="{{route('multiplerow.create')}}" enctype="multipart/form-data" id="addForm">
                @csrf

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label >Image Name*</label>
                            <input type="text" name="imgname" class="form-control" placeholder="Enter Photo Name" value="{{ old('imgname') }}">
                            <span class="error-message"></span>
                        </div>
                    </div>
                    
                </div>    
                
                
                <div class="row">
                    <div class="col-md-4 mt-3">
                        <div class="form-group">
                            <!-- <label>Profile Picture</label> -->
                            <div class="input-group">
                                <div class="custom-file">
                                    <input type="file" name="mutirowimg[]" accept="image/*" class="custom-file-input" multiple>
                                    <!-- <label class="custom-file-label" for="avtar">Choose picture</label> -->
                                </div>
                            </div>
                            <span class="error-message"></span>
                        </div>
                    </div>
                </div>
                        
                    <br>
                    <div class="col-md-8 mb-4">
                        <div class="ml-4"> 
                            <button type="submit" class="btn btn-info ms-mt-2 ms-block">Save</button> 
                        </div>
                    </div>
                </div>
            </form>






          </div>
        </div>
      </div>
    </div>
</div>


        
       
    </body>
</html>
