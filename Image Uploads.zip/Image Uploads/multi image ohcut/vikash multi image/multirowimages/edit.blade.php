<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

        <title>Image File Update in Laravel</title>

    <body>
    
        <div class="container">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="page-title-right mt-3" style="display: block"> 
            <a href="" class="btn btn-outline-secondary btn-rounded"><span class="uil uil-users-alt"></span> Student Edit Page</a> 
          </div>
          <h4 class="page-title mt-3">Edit Image Name of Students</h4>
        </div>
      </div>
      <div class="col-xl-12 col-lg-12">
        <div class="card">
          <div class="card-body  pb-5">
            
            <form  method="POST" action="{{route('multirowimg.edit',$alldata->id)}}" enctype="multipart/form-data" id="addForm">
                @csrf
                @method('PUT')
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label >Image Name*</label>
                            <input type="text" name="imgname" class="form-control" placeholder="Enter First Name" value="{{ $alldata->imgname }}" required>
                            <span class="error-message"></span>
                        </div>
                    </div>
                    
               


                <div class="row">
                    <div class="col-md-4 mt-3">
                        <div class="form-group">
                            <label>Profile Picture</label>
                            <div class="input-group">
                            @if(!empty($data))
                                @foreach($data as $myimages)
                                <div class="custom-file">
                                    <input type="file" name="mutirowimg" accept="image/*" class="custom-file-input" id="avtar">
                                    <label class="custom-file-label" for="avtar">Choose picture</label><br>
                                    <img src="{{asset('multirowimages/'.$myimages->mutirowimg)}}" class="img-thumbnail" width="100">
                                </div>
                                @endforeach
                            @endif    

                            </div>
                            <span class="error-message"></span>
                        </div>
                    </div>
                </div>
                        
                  
                    <div class="col-md-8 mb-4">
                        <div class="ml-4"> 
                            <button type="submit" class="btn btn-info ms-mt-2 ms-block">Update</button> 
                        </div>
                    </div>
                </div>
            </form>
          </div>
        </div>
      </div>
    </div>
</div>


        
       
    </body>
</html>
