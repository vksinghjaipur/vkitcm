<?php

namespace App\Http\Controllers;

use App\Models\Movie;
use Illuminate\Http\Request;

class MoviesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
       // $movies = Movie::latest()->paginate(4);
        //List Data ka Code hai
		$movies = Movie::paginate(4);

        return view('movies.index', compact('movies'))->with('i',(request()->input('page',1) - 1) * 4);
        
       //testing kar sakte hai
       //echo "<pre>";
        //print_r($movies);die;
        //return view('movies.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //Array Banaya
        $genres =['Action', 'Comdedy', 'Biopic', 'Horror', 'Drama', 'Romance'];
        
        return view('movies.create', compact('genres'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //Validation Yaha Lagaya

        $request->validate([
            'title'=>'required',
            'genre'=>'required',
            'release_year'=>'required',
            'poster'=>'required|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        // image name by default store kiya
        $imageName ='';
        if($request->poster){
            $imageName = time().'.'.$request->poster->extension();
            $request->poster->move(public_path('uploads'), $imageName);
        }

        //Object create kiya
        $data = new Movie;
        $data->title = $request->title;
        $data->genre = $request->genre;
        $data->release_year = $request->release_year;
        $data->poster = $imageName;

        $data->save();
       
         return redirect()->route('movies.index')->with('success', 'Movie has been added successfully.');
       
       //Vikash ji ka code 
       // echo "Data inserted Successfully";
       //return back()->with('status', 'successfully inserted');
       
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Movie  $movie
     * @return \Illuminate\Http\Response
     */
    public function show(Movie $movie)
    {
        //
        return view('movies.show', compact('movie'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Movie  $movie
     * @return \Illuminate\Http\Response
     */
    public function edit(Movie $movie)
    {
        //
        $genres =['Action', 'Comdedy', 'Biopic', 'Horror', 'Drama', 'Romance'];
        return view('movies.edit', compact('movie', 'genres'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Movie  $movie
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Movie $movie)
    {
        //
        $request->validate([
            'title'=>'required',
            'genre'=>'required',
            'release_year'=>'required',
        ]);

        $imageName ='';
        if($request->poster){
            $imageName = time().'.'.$request->poster->extension();
            $request->poster->move(public_path('uploads'), $imageName);
            $movie->poster = $imageName;
        }

        $movie->title=$request->title;
        $movie->genre=$request->genre;
        $movie->release_year=$request->release_year;
        $movie->update();
        return redirect()->route('movies.index')->with('success', 'Movie has been update successfully.' );

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Movie  $movie
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //Delete Code
        $movie = Movie::findOrFail($id);
        $movie->delete();
        return redirect()->route('movies.index')->with('success', 'Movie has been deleted successfully.');
    }
}
