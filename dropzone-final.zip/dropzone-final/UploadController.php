<?php 

namespace  App\Http\Controllers;  
use  Illuminate\Http\Request;  

class  UploadController  extends  Controller {  

/** 
 * Generate Upload View 
 * 
 * @return void 

 */  

  public  function index()  
  {  
      return view('dropzone.index');  
  }  

/** 
 * File Upload Method 
 * 
 * @return void 
 */  

  public  function uploadFile(Request $request)  
  {  
     $file = $request->file('file');  
     $fileName = time().'.'.$file->extension(); 
     $file->move(public_path('file'),$fileName);  

  return response()->json(['success'=>$fileName]);  

  }  

}