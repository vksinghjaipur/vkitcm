<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\VikashTestController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\MultiImageController;
use App\Http\Controllers\MultirowImageController;
use App\Http\Controllers\QrCodeController;

use App\Http\Controllers\OnChangeController;
use App\Http\Controllers\SelecttwoController;
use App\Http\Controllers\StudentAjaxController;
use App\Http\Controllers\JoinDataController;
use App\Http\Controllers\ReminderEventController;
use App\Http\Controllers\EnvVariableController;
use App\Http\Controllers\FormController;
use App\Http\Controllers\PluckController;
use App\Http\Controllers\DateFormatController;
use App\Http\Controllers\UploadController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::get("/",[VikashTestController::class, 'index']); 

Route::get("/salary",[VikashTestController::class, 'salaryGet'])->name('salary'); 
Route::get("/show-datatable",[VikashTestController::class, 'datatableShow'])->name('show.datatable'); 


Route::get("/student/list",[StudentController::class,"index"])->name('student.index');
Route::get("/student/add",[StudentController::class,"create"])->name('student.create');
Route::post("/student/add",[StudentController::class,"store"]);
Route::get("/student/edit/{id}",[StudentController::class,"edit"])->name('student.edit');
Route::PUT("/student/edit/{id}",[StudentController::class,"update"]);

// Search Student Route keyup onchange html
Route::get("/student/search",[OnChangeController::class,"index"])->name('student-onchange.index');
//get Student onChange
Route::get("student-details",[OnChangeController::class,"getStudentDetails"])->name('searchstudent');

// Search Student Route keyup onchange INPUT FIELD
Route::get("/student/search2",[OnChangeController::class,"showIndex"])->name('student-onchange.showindex');
//get Student onChange
Route::get("student-details2",[OnChangeController::class,"getStudents"])->name('showstudents');


// Search Student Route
Route::get("/student/search-by-ajax",[StudentAjaxController::class,"index"])->name('student-ajax.index');
//get Student onChange
Route::get("student-ajax-search",[StudentAjaxController::class,"getStudentByAjax"])->name('searchstudentajax');



// Select Two Search
Route::get("/search-select-two",[SelecttwoController::class,"index"])->name('selecttwo.index');




//Multiple Image Upload in Array Single Row Route
Route::get("/multiple-image/list",[MultiImageController::class,"index"])->name('multiple-image.index');
Route::get("/multiple-image/add",[MultiImageController::class,"create"])->name('multiple-image.create');
Route::post("/multiple-image/add",[MultiImageController::class,"store"]);
Route::get("/multiple-image/edit/{id}",[MultiImageController::class,"edit"])->name('multiple-image.edit');
Route::PUT("/multiple-image/edit/{id}",[MultiImageController::class,"update"]);



//Multiple Image Upload in Multiple Row and ID Route
Route::get("/multirowimg/list",[MultirowImageController::class,"index"])->name('multirowimg.index');
Route::get("/multirowimg/add",[MultirowImageController::class,"create"])->name('multirowimg.create');
Route::post("/multirowimg/add",[MultirowImageController::class,"store"]);
Route::get("/multirowimg/edit/{id}",[MultirowImageController::class,"edit"])->name('multirowimg.edit');
Route::PUT("/multirowimg/edit/{id}",[MultirowImageController::class,"update"]);

Route::get('/generate-qrcode', [QrCodeController::class, 'index'])->name('generateqr');

// Get Employe Details with Join from other table Route
Route::get("/employee/show",[JoinDataController::class,"index"])->name('joindata.index');



/*********************Full Calendar or Event Routes********************/
Route::get('/reminder', [ReminderEventController::class,'index'])->name('reminder');
Route::post('/reminder/add', [ReminderEventController::class,'addReminder'])->name('reminder.add');
Route::get('/reminder/getuserevents', [ReminderEventController::class,'getuserevents'])->name('reminder.getuserevents');
Route::post('/reminder/dragupdate', [ReminderEventController::class,'dargUpdateReminder'])->name('reminder.dragupdate');
Route::post('/reminder/eventdelete', [ReminderEventController::class,'deleteEventReminder'])->name('reminder.eventdelete');
  
Route::get('/reminder/userreminders', [ReminderEventController::class,'getUserReminderList'])->name('reminder.userreminders');    
   
Route::post('/reminder/markasdone', [ReminderEventController::class,'markAsDone'])->name('reminder.markasdone');
/*********************Ene Calendar Events**********************/



Route::get('show-variable',[EnvVariableController::class, 'index'])->name('showVariable');


/*---------------------------- Form1 Start -----------------------------*/
Route::get('show-form',[FormController::class,'index'])->name('showform');
Route::get('show-form/add',[FormController::class,'create'])->name('createform');
Route::post('show-form',[FormController::class,'store'])->name('storeForm');
Route::get('edit-form/{id}',[FormController::class,'edit'])->name('editForm');
Route::post('edit-form/{id}',[FormController::class,'update'])->name('updateForm');

/*---------------------------- Form1 End -------------------------------*/


Route::get('show-pluck-page',[PluckController::class,'index'])->name('showpluck');


/*---------------------------- Date Format Start------------------------*/
Route::get('show-date-format',[DateFormatController::class,'index'])->name('showDate');
/*---------------------------- Date Format End -------------------------*/


/*---------------------------- DropZone File Uloading Start------------------------*/
Route::get('ui', [ UploadController::class, 'index' ]);
Route::post('upload', [ UploadController::class, 'uploadFile' ])->name('uploadFile');
/*---------------------------- DropZone File Uloading End -------------------------*/












// Route::name('multiplerow.')->group(function () {
// Route::get("/multirowimg/list",[MultirowImageController::class,"index"])->name('index');
// Route::get("/multirowimg/add",[MultirowImageController::class,"create"])->name('create');
// Route::post("/multirowimg/add",[MultirowImageController::class,"store"]);
// Route::get("/multirowimg/edit/{id}",[MultirowImageController::class,"edit"])->name('edit');
// Route::PUT("/multirowimg/edit/{id}",[MultirowImageController::class,"update"]);
// Route::get("/multirowimg/delete/{id}",[MultirowImageController::class,"destroy"])->name('destroy');

// });

