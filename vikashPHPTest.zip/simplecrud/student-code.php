<?php
    include_once 'dbconfig.php';

    if(isset($_POST['insert_buttton']))
    {    
        $fullname = $_POST['fullname'];
        $course = $_POST['course'];
        $email = $_POST['email'];

        $query = "INSERT INTO newstudents (fullname,course,email) VALUES ('$fullname','$course','$email')";
        $result = mysqli_query($conn, $query); 
        if($result) 
        {
            echo "Data Inserted Successfully!";
        } 
        else
        {
            echo "Data Not Inserted!. Error: " . $sql . "" . mysqli_error($conn);
        }
    }
?>