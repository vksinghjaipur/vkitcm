-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 22, 2024 at 04:27 PM
-- Server version: 5.7.36
-- PHP Version: 8.1.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vdatefilter`
--

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
CREATE TABLE IF NOT EXISTS `employees` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gender` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `position` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `name`, `last_name`, `email`, `gender`, `position`, `created_at`, `updated_at`) VALUES
(1, 'Jedediah', 'Armstrong', 'qleannon@example.net', 'Female', 'Project Manager', '2024-01-21 18:30:00', '2024-01-22 10:16:06'),
(2, 'Montana', 'Hansen', 'percy78@example.com', 'Male', 'Sales Manager', '2024-01-21 18:30:00', '2024-01-22 10:16:06'),
(3, 'Leonard', 'Labadie', 'parisian.tianna@example.net', 'Male', 'Accountant', '2024-01-21 18:30:00', '2024-01-22 10:16:06'),
(4, 'Danyka', 'Walter', 'augustus.boyle@example.com', 'Female', 'CEO', '2024-01-21 18:30:00', '2024-01-22 10:16:06'),
(5, 'Janice', 'Corkery', 'davis.joshua@example.net', 'Female', 'Accountant', '2024-01-21 18:30:00', '2024-01-22 10:16:06'),
(6, 'Leonor', 'Stracke', 'carter.eduardo@example.net', 'Male', 'CEO', '2024-01-21 18:30:00', '2024-01-22 10:16:06'),
(7, 'Phyllis', 'Bruen', 'gaylord.elwin@example.com', 'Female', 'Accountant', '2024-01-20 18:30:00', '2024-01-22 10:16:06'),
(8, 'Graham', 'Monahan', 'romaguera.alexis@example.org', 'Male', 'HR Manager', '2024-01-20 18:30:00', '2024-01-22 10:16:06'),
(9, 'Haylie', 'Schaefer', 'gia62@example.com', 'Female', 'Project Manager', '2024-01-20 18:30:00', '2024-01-22 10:16:06'),
(10, 'Alverta', 'Jacobson', 'wolff.lorenz@example.org', 'Male', 'Sales Manager', '2024-01-20 18:30:00', '2024-01-22 10:16:06'),
(11, 'Eunice', 'Pfeffer', 'osporer@example.net', 'Female', 'CEO', '2024-01-20 18:30:00', '2024-01-22 10:16:06'),
(12, 'Elnora', 'Halvorson', 'murphy73@example.com', 'Female', 'Sales Manager', '2024-01-20 18:30:00', '2024-01-22 10:16:06'),
(13, 'Cheyanne', 'Stanton', 'arnoldo76@example.net', 'Male', 'Project Manager', '2024-01-27 02:21:00', '2024-01-22 10:16:06'),
(14, 'Cooper', 'Schmeler', 'tbartoletti@example.net', 'Female', 'CEO', '2024-01-22 10:53:00', '2024-01-22 10:16:06'),
(15, 'Maritza', 'Cremin', 'turcotte.mackenzie@example.net', 'Male', 'Sales Manager', '2024-01-25 18:40:00', '2024-01-22 10:16:06'),
(16, 'Janice', 'Gusikowski', 'kstoltenberg@example.net', 'Female', 'Sales Manager', '2024-01-25 08:46:00', '2024-01-22 10:16:06'),
(17, 'Dora', 'Conroy', 'melisa.hudson@example.org', 'Female', 'CEO', '2024-01-22 17:19:00', '2024-01-22 10:16:06'),
(18, 'Gilberto', 'Brown', 'dulce54@example.net', 'Female', 'Accountant', '2024-01-21 21:03:00', '2024-01-22 10:16:06'),
(19, 'Sigmund', 'Feil', 'trycia34@example.org', 'Female', 'Accountant', '2024-01-19 07:33:00', '2024-01-22 10:16:07'),
(20, 'Charles', 'Feil', 'gutkowski.susie@example.org', 'Female', 'Accountant', '2024-01-15 16:12:00', '2024-01-22 10:16:07'),
(21, 'Sammy', 'Oberbrunner', 'bjakubowski@example.net', 'Male', 'Accountant', '2024-01-17 01:03:00', '2024-01-22 10:16:07'),
(22, 'Leo', 'Ritchie', 'pblanda@example.com', 'Female', 'Accountant', '2024-01-19 07:16:00', '2024-01-22 10:16:07'),
(23, 'Darrel', 'Schaden', 'marques63@example.net', 'Female', 'Project Manager', '2024-01-20 07:39:00', '2024-01-22 10:16:07'),
(24, 'Consuelo', 'Orn', 'qokeefe@example.org', 'Female', 'Accountant', '2024-01-20 08:02:00', '2024-01-22 10:16:07'),
(25, 'Tiffany', 'Murazik', 'turner.juana@example.net', 'Male', 'Accountant', '2024-01-16 19:20:00', '2024-01-22 10:16:07'),
(26, 'Agnes', 'Reynolds', 'aauer@example.com', 'Female', 'Sales Manager', '2024-01-20 00:20:00', '2024-01-22 10:16:07'),
(27, 'Roosevelt', 'Grant', 'mkilback@example.net', 'Male', 'Sales Manager', '2024-01-10 03:15:00', '2024-01-22 10:16:07'),
(28, 'Forest', 'Keebler', 'astrid.pfeffer@example.org', 'Male', 'Project Manager', '2024-01-20 15:22:00', '2024-01-22 10:16:07'),
(29, 'Baylee', 'McClure', 'njacobi@example.org', 'Male', 'Accountant', '2024-01-13 22:00:00', '2024-01-22 10:16:07'),
(30, 'Dortha', 'Howell', 'hbartell@example.com', 'Female', 'Sales Manager', '2024-01-02 18:44:00', '2024-01-22 10:16:07'),
(31, 'Jo', 'Rolfson', 'otho.padberg@example.org', 'Female', 'Project Manager', '2023-12-10 11:04:00', '2024-01-22 10:16:07'),
(32, 'Bulah', 'Durgan', 'kenyatta.predovic@example.net', 'Male', 'Sales Manager', '2023-12-23 20:44:00', '2024-01-22 10:16:07'),
(33, 'Arvid', 'Ward', 'jordon64@example.net', 'Male', 'CEO', '2023-12-13 14:19:00', '2024-01-22 10:16:07'),
(34, 'Laverna', 'Larson', 'mosciski.ruby@example.net', 'Female', 'Accountant', '2023-12-08 04:46:00', '2024-01-22 10:16:07'),
(35, 'Loren', 'Dach', 'moore.aliza@example.net', 'Male', 'Project Manager', '2023-12-17 23:17:00', '2024-01-22 10:16:07'),
(36, 'Daphne', 'Swift', 'valtenwerth@example.org', 'Male', 'Project Manager', '2023-12-27 07:23:00', '2024-01-22 10:16:07'),
(37, 'Chandler', 'Ebert', 'eloisa.bins@example.net', 'Female', 'Sales Manager', '2024-11-23 04:35:00', '2024-01-22 10:16:07'),
(38, 'Kayley', 'Hickle', 'rbednar@example.net', 'Female', 'Accountant', '2024-10-10 10:34:00', '2024-01-22 10:16:07'),
(39, 'Irving', 'Sporer', 'welch.sage@example.com', 'Female', 'CEO', '2024-09-17 07:46:00', '2024-01-22 10:16:07'),
(40, 'Enos', 'Schimmel', 'abigale.ritchie@example.org', 'Female', 'HR Manager', '2024-04-05 00:26:00', '2024-01-22 10:16:07'),
(41, 'Ward', 'McCullough', 'cora.watsica@example.com', 'Female', 'CEO', '2024-09-21 17:33:00', '2024-01-22 10:16:07'),
(42, 'Dane', 'Streich', 'loren28@example.net', 'Female', 'Sales Manager', '2024-03-12 23:52:00', '2024-01-22 10:16:07'),
(43, 'Carolyne', 'Wilderman', 'yoshiko.bins@example.net', 'Female', 'Project Manager', '2023-04-23 10:12:00', '2024-01-22 10:16:07'),
(44, 'Lavonne', 'Deckow', 'maia62@example.com', 'Female', 'CEO', '2023-07-02 21:09:00', '2024-01-22 10:16:07'),
(45, 'Ross', 'Lueilwitz', 'heathcote.karine@example.net', 'Female', 'CEO', '2023-06-20 13:02:00', '2024-01-22 10:16:07'),
(46, 'Ruthie', 'Waelchi', 'jayden.schinner@example.org', 'Female', 'Project Manager', '2023-11-19 19:30:00', '2024-01-22 10:16:07'),
(47, 'Nicole', 'Shields', 'mlittle@example.com', 'Female', 'Accountant', '2023-06-17 23:55:00', '2024-01-22 10:16:07'),
(48, 'Marjolaine', 'Hoppe', 'kiana45@example.net', 'Female', 'Sales Manager', '2023-03-14 01:38:00', '2024-01-22 10:16:07');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `connection` text COLLATE utf8_unicode_ci NOT NULL,
  `queue` text COLLATE utf8_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2024_01_22_153837_create_employees_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Vikash Singh', 'vksinghjaipur@gmail.com', '2024-01-02 08:49:50', '$2y$10$G49lYlDZYHUQkHOYtuZW8OFPbZcQNe6XWpsy25wdy9IfsNC4c5YBG', NULL, '2024-01-02 08:49:50', NULL),
(2, 'Garima Singh', 'garima@gmail.com', '2024-01-04 08:49:55', '$2y$10$G49lYlDZYHUQkHOYtuZW8OFPbZcQNe6XWpsy25wdy9IfsNC4c5YBG', NULL, '2024-01-04 08:49:55', NULL),
(3, 'Priya Singh', 'priya@gmail.com', '2024-01-07 08:49:55', '$2y$10$G49lYlDZYHUQkHOYtuZW8OFPbZcQNe6XWpsy25wdy9IfsNC4c5YBG', NULL, '2024-01-07 08:49:55', NULL),
(4, 'Amit Soni', 'amit@gmail.com', '2024-01-14 08:49:55', '$2y$10$G49lYlDZYHUQkHOYtuZW8OFPbZcQNe6XWpsy25wdy9IfsNC4c5YBG', NULL, '2024-01-14 08:49:55', NULL),
(5, 'Rajesh Gupta', 'rajesh@gmail.com', '2024-01-21 08:49:55', '$2y$10$G49lYlDZYHUQkHOYtuZW8OFPbZcQNe6XWpsy25wdy9IfsNC4c5YBG', NULL, '2024-01-21 08:49:55', NULL),
(6, 'Amitabh Bachhan', 'amitabh@gmail.com', '2023-12-08 08:49:55', '$2y$10$G49lYlDZYHUQkHOYtuZW8OFPbZcQNe6XWpsy25wdy9IfsNC4c5YBG', NULL, '2023-12-07 18:30:00', NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
