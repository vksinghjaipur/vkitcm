<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Carbon\Carbon;

class TwoDateFilterController extends Controller
{
    
    //Method 1
    public function index(Request $request)
    {
        $startDate = Carbon::createFromFormat('d/m/Y', '01/01/2021');
        $endDate = Carbon::createFromFormat('d/m/Y', '06/01/2021');
  
        $users = User::select('id', 'name', 'email', 'created_at')
                        ->whereBetween('created_at', [$startDate, $endDate])
                        ->get();
  
        dd($users);
    }

    //Method 2
    public function indexMethodTwo(Request $request)
    {
        $startDate = Carbon::createFromFormat('d/m/Y', '01/01/2021');
        $endDate = Carbon::createFromFormat('d/m/Y', '06/01/2021');
  
        $users = User::select('id', 'name', 'email', 'created_at')
                        ->where('created_at', '>=', $startDate)
                        ->where('created_at', '<=', $endDate)
                        ->get();
  
        dd($users);
    }


    public function Method_3(Request $request)
    {
        $startDate = '01/01/2021';
        $endDate = '06/01/2021';
  
        $users = User::select('id', 'name', 'email', 'paid_date')
                        ->whereDate('paid_date', '>=', $startDate)
                        ->whereDate('paid_date', '<=', $endDate)
                        ->get();
  
        dd($users);
    }
}
