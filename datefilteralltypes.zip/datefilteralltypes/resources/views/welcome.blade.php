<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

        <title>Date Filter in Laravel All Types</title>

    <body>
    
        <div class="container mt-3">
          <h2><u>DATE FILTER IN LARAVEL</u></h2>
          <h3><center>GET ALL DATA BY DATE FILTER</center></h3> 

          <table class="table table-bordered">
            <thead class="text-primary">
              <tr>
                <th>Sr. No.</th>
                <th>Date Filter Name</th>
                <th>Date Fillter Link</th>
                <th>Image</th>
              </tr>
            </thead>
            <tbody>
              
              <tr>
                <td>1</td>
                <td>Get Data Between Two Dates</td>
                <td><a href="#">Show Page</a></td>
                <td><a href="javascript:void(0);">whereBetween(), where() and whereDate()</a></td>
              </tr>
              
              <tr>
                <td>2</td>
                <td>Datatables Date Range Filter</td>
                <td><a href="{{route('datatablefilter.index')}}">Show Page</a></td>
                <td><a href="javascript:void(0);">Not Ok</a></td>
              </tr>

               <tr>
                <td>3</td>
                <td>Date Filter All Types (Bluebird)</td>
                <td><a href="{{route('employee.index')}}">Show Page</a></td>
                <td><a href="javascript:void(0);">Testing</a></td>
              </tr>

             
            </tbody>
          </table>
        </div>


        
       
    </body>
</html>
