<?php




/* Contact page route */
Route::get('/contact', [PagesController::class,'index'])->name('contact');
Route::post('contact/send',[PagesController::class,'send'])->name('contact.send');