<?php
namespace App\Http\Controllers\Frontend;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Mail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use App\Models\Page;
use App\Models\Service;
use App\Models\Testimonial;
use App\Models\User;
use App\Models\Blog;
use App\Models\Comment;
use App\Models\Contact;
use Carbon\Carbon;
use Auth;   
use DB;
use Toastr;

class PagesController extends Controller
{
    public function index()
    {
        return view('frontend.pages.contact');
    }

    public function send(Request $request)
    {  
         $request->validate([
            'name' => 'required',
            'email' => 'required|email',
            'phone' => 'required|numeric',
            'subject' => 'required',
            'message' => 'required'
        ]);
  
        Contact::create($request->all());
  
        return redirect()->back()
                         ->with(['message' => 'Thank you for contact us. We will contact you shortly.']);
    }

    

    /* Show Blogs */
    // public function getBlog()
    // {
    //     $month = request('month');
    //     $year  = request('year');
    //     $blogs = Blog::latest()->withCount('comments')
    //     ->leftjoin('users','users.id','=','blogs.created_by')
    //     ->when($month, function ($query, $month) {
    //     return $query->whereMonth('created_at', Carbon::parse($month)->month);
    //     })
    //     ->when($year, function ($query, $year) {
    //     return $query->whereYear('created_at', $year);
    //     })
    //     ->where('blogs.status',1)
    //     ->select('blogs.*','users.username')
    //     ->paginate(6);

        
    //     $recentBlog=Blog::latest()->withCount('comments')
    //     ->leftjoin('users','users.id','=','blogs.created_by')
    //     ->when($month, function ($query, $month) {
    //     return $query->whereMonth('created_at', Carbon::parse($month)->month);
    //     })
    //     ->when($year, function ($query, $year) {
    //     return $query->whereYear('created_at', $year);
    //     })
    //     ->where('blogs.status',1)
    //     ->select('blogs.*','users.username')
    //     ->orderBy('id','DESC')
    //     ->limit(5)->get();

    //     //echo "<pre>";print_r($recentBlog); die();    
    //     return view('frontend.pages.blogs',compact('blogs','recentBlog'));
    // }

    // public function BlogDetail(Request $request, $slug)
    // {
    //     $blog=Blog::leftjoin('users','users.id','=','blogs.created_by')
    //     ->select('blogs.*','users.username')
    //     ->where('slug', $slug)->first(); 
    //     //echo "<pre>";print_r($blogs); die();  
    //     return view('frontend.pages.blog-detail',compact('blog'));
    // }



    /* BLOG COMMENT */
    // public function blogComments(Request $request, $id)
    // {
    //     $request->validate([
    //         'comment'  => 'required'
    //     ]);

    //     $blogs = Blog::find($id);
    //     $blogs->comments()->create(
    //         [
    //             'user_id'   => Auth::id(),
    //             'comment'   => $request->comment
    //         ]
    //     );
    //     return back();
    // }


    // public function getPrivacyPage()
    // {
    //     return view('frontend.mobile-pages.privacy');
    // }

    // public function getTermsPage()
    // {
    //     return view('frontend.mobile-pages.terms');
    // }

    

}
