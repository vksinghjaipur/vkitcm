<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!-- Bootstrap CSS -->
  <link rel="icon" type="images/png" sizes="32x32" href="{{asset('images/favicon-32x32.png')}}">
  <link href="{{asset('frontend/css/bootstrap.min.css')}}" rel="stylesheet" type="text/css">
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"
    type="text/css">
    <link rel="stylesheet" href="{{ asset('css/fontawesome-all.min.css') }}">
      
  <link href="{{asset('frontend/css/styles.css')}}" rel="stylesheet" type="text/css">
  <link href="{{asset('frontend/css/slick.css')}}" rel="stylesheet" type="text/css">

  <link href="{{asset('frontend/css/animate.css')}}" rel="stylesheet" type="text/css">
  <title>Homes Await</title>
  <style type="text/css">
  .form-input {
    margin-bottom: 15px;
  }
  .login-n-box {
    max-width: 470px !important;
  }
  </style>
</head>

<body>
  <div class="login-page inner-top pt-50 pb-50">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="login-n-box">
              
              <div class="setlogo-heading">
                <a href="{{url('/')}}">
                    <img class="login-logo" src="{{asset('images/logo-main.svg')}}">
                </a>
                <h1>Forgot Password ?</h1>
                  
                 <div class="col-lg-12 col-md-12 col-sm-12">
                     @include('flash::message')
                      @if (Session::has('status'))
                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            <p>
                                <i class="fas fa-bolt"></i> {{ Session::get('status') }}
                            </p>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                      @endif

                      @if ($errors->any())
                        <!-- Validation Errors -->
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <p>
                                <i class="fas fa-exclamation-triangle"></i> @lang('Please fix the following errors & try again!')
                            </p>
                            <ul>
                                @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                                @endforeach
                            </ul>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        @endif

                  </div>


            </div>
              
              <form role="form" method="POST" action="{{route('password.email')}}">
              @csrf
              

              <div class="row">

                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                  <div class="form-input">
                    <input type="email" class="" id="email" name="email" value="{{ old('email') }}" placeholder="{{ __('E-Mail Address') }}" aria-label="email" aria-describedby="email" required>
                  </div>
                </div>
                
                               
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                  <div class="form-input">
                    <label class="anchor-link">Existing User?<a href="{{ route('login') }}" class="achor-text"> Log In</a></label>
                  </div>
                </div>
                
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                  <div class="form-input">
                    <button type="submit" class="btn btn-primary w100">Email Passowrd Reset Link</button>
                    <!-- <input type="submit" class="" name="Sign In"> -->
                  </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                  <div class="or-sign">
                    <span>Or Sign In With</span>
                  </div>
                </div>

              

                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                  <div class="form-input">
                    <label class="anchor-link">Don't Have An Account? <a href="{{route('register') }}" class="achor-text"> Sign Up Now</a></label>
                    
                  </div>
                </div>
              </div>

            </form>
            </div>
          </div>
        </div>
      </div>
  </div>

  <script src="{{asset('frontend/js/jquery.min.js')}}"></script>
  <script src="{{asset('frontend/js/bootstrap.min.js')}}"></script>
  <script src="{{asset('frontend/js/slick.js')}}"></script>
  <script src="{{asset('frontend/js/wow.min.js')}}"></script>
  <!-- <script src="js/custom.js"></script> -->
</body>

</html>