<!doctype html>

<html lang="en">



<head>

  <!-- Required meta tags -->

  <meta charset="utf-8">

  <meta name="keywords" content="Html5, CSS3, Bootstarp5 Javascript & Jquery">

  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Page Title -->

  <title>Forgot Password</title>

  <!-- Bootstrap CSS -->

  <link rel="icon" type="image/png" sizes="32x32" href="{{asset('images/favicon-32x32.png')}}">

  <link rel="stylesheet" href="{{ asset('css/fontawesome-all.min.css') }}">

  <link rel="stylesheet" href="{{ asset('frontend/login/css/bootstrap.min.css') }}">

  <link rel="stylesheet" href="{{ asset('frontend/login/css/style.css') }}">

  

  <style type="text/css">

  .close {

    float: right;

    font-size: 1.5rem;

    font-weight: 600;

    line-height: 1;

    color: rgba(0, 0, 0, 0.6);

    text-shadow: none;

    opacity: .5;

  }

  button.close {

    padding: 0;

    background-color: transparent;

    border: 0;

    -webkit-appearance: none;

    -moz-appearance: none;

    appearance: none;

  }

  </style>



</head>



<body>

  <div class="login-page">

    <div class="login-inner">

      <div class="container">

        <div class="row">

          <div class="col-lg-12 col-md-12 col-sm-12">

            <div class="header-login">

              <a href="{{('/')}}"><img src="{{asset('images/logo.svg')}}"></a>

            </div>

            <div class="login-from">

              <div class="container">

                <div class="row">

                  <div class="col-lg-12 col-md-12 col-sm-12">
                    <h2>Forgot Password ?</h2>
                     @include('flash::message')
                      @if (Session::has('status'))
                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            <p>
                                <i class="fas fa-bolt"></i> {{ Session::get('status') }}
                            </p>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                      @endif

                      @if ($errors->any())
                        <!-- Validation Errors -->
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <p>
                                <i class="fas fa-exclamation-triangle"></i> @lang('Please fix the following errors & try again!')
                            </p>
                            <ul>
                                @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                                @endforeach
                            </ul>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        @endif

                  </div>

                  

                  <form role="form" method="POST" action="{{route('password.email')}}">
                  @csrf
                  <!-- redirectTo URL -->

                    <div class="col-lg-12 col-md-12 col-sm-12">
                      <div class="form-input">
                        <input type="email" class="" id="email" name="email" value="{{ old('email') }}" placeholder="{{ __('E-Mail Address') }}" aria-label="email" aria-describedby="email" required>
                      </div>
                    </div>

                    <div class="col-lg-12 col-md-12 col-sm-12">

                      <div class="form-input">
                        <input type="submit" class="" name="Log In">
                      </div>
                    </div>

                  </form>
                  
                    <div class="col-lg-12 col-md-12 col-sm-12">
                      <div class="form-input">
                        <div class="for-cre">
                          <a href="{{ route('register') }}" class="text-gray">
                          SIGN UP
                          </a>

                          @if (Route::has('register'))
                          <!-- <a href="sign-up.html">Create new account</a> -->
                          <a href="{{ route('login') }}" class="text-gray">
                          LOGIN
                          </a>
                          @endif
                        </div>
                      </div>
                    </div>

                </div>

              </div>

            </div>

          </div>

        </div>

      </div>

    </div>



    <div class="slider-video">

      <video autoplay muted loop id="myVideo">

        <source src="https://code-theme.com/html/findhouses/video/7.mp4" type="video/mp4">

      </video>

    </div>

  </div>



  <script src="{{ asset('frontend/login/js/jquery.min.js') }}"></script>

  <script src="{{ asset('frontend/login/js/bootstrap.min.js') }}"></script>



</body>



</html>