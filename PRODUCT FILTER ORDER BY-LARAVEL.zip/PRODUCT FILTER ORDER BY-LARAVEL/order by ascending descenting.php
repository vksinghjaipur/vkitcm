<?php


if(isset($_GET['price']) && !empty($_GET['price'])){
            if($_GET['price'] == 'price_LH')
            {
            $query->orderBy('properties.price','ASC');
            }
        }
        
        if(isset($_GET['price']) && !empty($_GET['price'])){
            if($_GET['price'] == 'price_HL')
            {
            $query->orderBy('properties.price','DESC');
            }
        }


  <form class="row" action="{{route('saleproperty')}}" method="GET">

         <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
             <div class="form-input">
               <label>Price</label>
               <input type="text" name="price_from" value="{!! isset($_GET['price_from']) && !empty($_GET['price_from']) ? $_GET['price_from']:'' !!}" placeholder="Min" />
             </div>
          </div>

           <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
             <div class="form-input">
               <label>Price</label>
               <input type="text" name="price_to" value="{!! isset($_GET['price_to']) && !empty($_GET['price_to']) ? $_GET['price_to']:'' !!}" placeholder="Max" />
             </div>
           </div>

        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 mt-20">
           <!-- <a href="javascript:void(0);" class="btn btn-primary">Apply Filters</a> -->
           <input type="submit" class="btn btn-primary" value="Apply Filters">
       </div>   

     </form>   