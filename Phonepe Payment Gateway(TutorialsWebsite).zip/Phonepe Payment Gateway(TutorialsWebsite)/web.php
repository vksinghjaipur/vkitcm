
<?php




//PAYMENT FORM
Route::get('payment', [\App\Http\Controllers\PaymentController::class, 'index'])->name('payment');

//SUBMIT PAYMENT FORM ROUTE
Route::post('pay-now', [\App\Http\Controllers\PaymentController::class, 'submitPaymentForm'])->name('pay-now');

//CALLBACK ROUTE
Route::get('confirm', [\App\Http\Controllers\PaymentController::class, 'confirmPayment'])->name('confirm');
