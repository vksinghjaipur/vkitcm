<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');


if (!function_exists('checkCouponAmmount'))

{
  function checkCouponAmmount($cart=array())

    {
        $CI =& get_instance();
        if($CI->session->userdata('user_coupon')){
          $query = 'SELECT coupon_amount,cart_amount,coupon_type FROM coupon WHERE coupon_code = "'.$CI->session->userdata('user_coupon_code').'" AND coupon_quantity > 0 AND UNIX_TIMESTAMP() < UNIX_TIMESTAMP(coupon_expiry_date)';
          $coupon_amount = $CI->db->query($query)->result_array();
          // echo "<pre>";
          // print_r ($coupon_amount);
          // echo "</pre>";die;
          if ($coupon_amount) {
            $cart_amount = $CI->cart->total();
            if($coupon_amount[0]['cart_amount']!="" && $coupon_amount[0]['cart_amount']>$cart_amount) {
                $CI->session->unset_userdata('user_coupon');
                $CI->session->unset_userdata('user_coupon_code');
                $CI->session->unset_userdata('user_coupon_type');
            }
            if($CI->session->userdata('user_coupon')>$cart_amount){
                $CI->session->unset_userdata('user_coupon');
                $CI->session->unset_userdata('user_coupon_code');
                $CI->session->unset_userdata('user_coupon_type'); 
            }
          }
          
        }
    }
}

if (!function_exists('cartDropdown'))

{

    function cartDropdown($cart=array())

    {

        $CI =& get_instance();

        $html = '';

        $amount = $count = $shipping = $GST = array();

        $c = count($cart)-1;

        $site_url = base_url();

        $c1=-1;

        $no_of_products = count($cart);

        //$coupon = $CI->session->userdata("coupon");

        if(!empty($cart))

        {

            //print_r($cart);echo $no_of_products; die;
            $html.='<div class="cartheadert">
                    <h4>My Cart <a href="javascript:void(0);" class="closeATcModal cartclose"><img src="'.base_url().'assets/user/images/material-close.png" alt="close" width="18"></a></h4>
                  </div>';


              // echo "<pre>";
              // print_r($cart);

            foreach ($cart as $key => $value)
            {
              $price = 0;
              if($value['options']['shop_rewards']==0){
                $price = (($value['price']*$value["qty"]));
              }
              $amount[] = $price;
              $cart_amount = array_sum($amount);
              $c1++;

              $html.='<div class="row pt-4 border-bottom pb-2">
                       <div class="col-md-4 col-sm-4 col-4">';
                          if($value["options"]["product_photos"]!=''){
                             $html.='<img src="'.base_url($value['options']['product_photos']).'" style="width:100%;" alt="'.$value['name'].'">';
                          }else{
                             $html.='<img src="'.base_url('assets/product_image/WPI.jpg').'" style="width:100%;" alt="image">';
                          }
                  $html.='</div>
                       <div class="col-md-8 col-sm-8 col-8">
                        <input type="hidden" name="rowid[]" value="'.$value['rowid'].'">
                          <h5>'.word_limiter($value["name"], 2).'</h5>';
                          if($value['options']['shop_rewards']==0){
                            $html .= '<h4 class="cartprice">$'.$value["price"].'</h4>';
                          }else{
                            $html .= '<h4 class="cartprice">'.$value["price"].' Points</h4>';
                          }
                          if($value['options']['shop_rewards']==0){
                            $html .= '<div class="d-flex">
                               <div class="product-quality upqty ptotopcert">
                                  <div class="dec qtybutton">-</div>
                                  <input class="cart-plus-minus-box input-text qty text submitQty1" name="qty[]" value="'.$value["qty"].'">
                                  <div class="inc qtybutton">+</div>
                               </div>
                               <div class="qty_title qtycart ms-2"> QTY </div>
                            </div>';
                          }
                       $html .= '</div>
                       <div class="col-md-12 col-sm-12 col-12 text-right">
                          <a href="javascript:void(0)" data-id="'.$value["rowid"].'" class="btn-trash-cart deleteproduct"> <i class="fa fa-trash"></i> Remove </a>
                       </div>
                    </div>';
            }

            $html.='<div class="pt-5"></div>
              <div class="cart-ship-box mt-2">
                 <p class="mb-0">You are only <span> $37.66</span> away from <br> <span> free shipping!</span></p>
              </div>
              <div class="cart-subtotal-box mt-2">
                 <p class="mb-0">Subtotal: <span> $'.number_format(($cart_amount),2).'</span> </p>
              </div>
              <div class="row justify-content-center pt-2 pb-3">
                 <div class="col-md-9 col-sm-9 col-12 mt-1">
                    <a href="'.base_url('shopping-cart').'" class="theme-button"><span>VIEW CART </span> <i class="fa fa-angle-right"> </i></a>
                 </div>
              </div>';
        }else{

            $html.='<div class="single-cart">
                      <h3>Add Product In Cart</h3>
                    </div>';

        }

        return $html;

    }

}



if (!function_exists('productAmountCount'))

{

	function productAmountCount($cart=array())

	{

    $html = '';

    $amount = $count = array();

    foreach ($cart as $key => $value) {

      $amount[] = $value['subtotal'];

      $count[] = $value['qty'];

    }

    //print_r(array_sum($amount));

    //print_r(array_sum($count));

    $html = '<div class="items-cart-inner">

              <div class="total-price-basket">

                <span class="lbl">cart -</span>

                <span class="total-price">

                  <span class="value">'.array_sum($amount).'</span>

                  <span class="sign"> $</span>

                </span>

              </div>

              <div class="basket">

                <i class="glyphicon glyphicon-shopping-cart"></i>

              </div>

              <div class="basket-item-count"><span class="count">'.array_sum($count).'</span></div>

            </div>';

    return $html;

  }

}



if(!function_exists('trackOrderHtml'))

{

  function trackOrderHtml($data=array(),$order_status_name='')

  {

    $html = '';

    //echo "<pre>"; print_r($data);

      $html .= '<div class="content">

        <div class="row">

          <div class="col-xs-12">

            <div class="box">

              <div class="box-header">';

                $html .= '<h3 class="box-title">Track Order Products ('.$order_status_name.') </h3>

              </div>

              <div class="box-body table-responsive no-padding">

                <table class="table table-hover">

                  <thead>

                    <tr>

                      <th>Product Name</th>

                      <th>Quantity</th>

                    </tr>

                  </thead>

                  <tbody>';

                    foreach ($data as $key => $value) :

                      $html .= '

                      <tr>

                        <td>'.$value['name'].'</td>

                        <td>'.$value['quantity'].'</td>

                      </tr>';

                    endforeach;

                  $html .= '</tbody>

                </table>

              </div><!-- /.box-body -->

            </div><!-- /.box -->

          </div>

        </div>

      </div>';

    return $html;

  }

}

if (!function_exists('getCartProductname'))

{

  function getCartProductname($id)

  {
      $CI =& get_instance();
      $data = $CI->common->getsData('products',array('productid'=>$id),'product_name');
      return $data['product_name'];
  }
}


// ------------------------------------------------------------------------

/* End of file translate_helper.php */

/* Location: ./system/helpers/translate_helper.php */