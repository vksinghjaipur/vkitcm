<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

if (!function_exists('desktopMenu'))
{
  function desktopMenu($listOfItems) {
       //echo "<pre>";
       //print_r($listOfItems); die;
      $html = '';
      $href = '';
      foreach ($listOfItems as $item) {
        if(isset($item['childs']) && $item['childs']) { 
            $href = str_replace(" ","-",base_url("products/".url_title(strtolower($item['category']))."/pr?catid=".$item['c_id']));
            // $href = str_replace(" ","-",base_url("category-list/".url_title(strtolower($item['category']))."/".$item['c_id']));
        }else{
            $href = str_replace(" ","-",base_url("products/".url_title(strtolower($item['category']))."/pr?catid=".$item['c_id']));
            // $href = str_replace(" ","-",base_url("category-list/".url_title(strtolower($item['category']))."/".$item['c_id']));
        }
        $html .= '<div class="d_menu drp-menu">
                    <a href="'.$href.'">'.$item['category']; 
                      if(isset($item['childs']) && $item['childs']) {
                        $html .= '<i class="fa fa-caret-down" aria-hidden="true"></i>';
                      }
          $html .= '</a>';
                    if(isset($item['childs']) && $item['childs']) {
                      $html .= '<ul class="mega-menu-style mega-menu-mrg-1 pt-0 bgf5">
                                  <div class="container-sm">
                                  <div class="row p-2" style="padding-left: 4px !important;">
                                     <div class="menu-megaflex">
                                        <div class="d_in_flex">';
                                $html .=  subMenu1($item['childs'],$item['category'],$item['c_id'],0); 
                              $html .= '</div>
                                     </div>
                                  </div>
                                  </div>
                              </ul>';
                      }
        $html .= '</div>';
      }
      return $html;
  }
}


if (!function_exists('subMenu1'))
{
  function subMenu1($listOfItems,$parentcat,$parent_id,$m,$lc=0) {
      $html = '';
      $i=1;
      foreach ($listOfItems as $item) {  
        $html .= '<div class="menu_mega main-'.$lc.' '.((isset($item['childs']) && $item['childs'])?'submega_menu':'').'">';
          if(isset($item['childs']) && $item['childs']) { 
            // $href=base_url('category-list/'.url_title(strtolower($parentcat)).'/'.url_title(strtolower($item['category'])).'/'.$item['c_id']);
            $href = str_replace(" ","-",base_url("products/".url_title(strtolower($item['category']))."/pr?catid=".$item['c_id']));
          }else{
            $href = str_replace(" ","-",base_url("products/".url_title(strtolower($item['category']))."/pr?catid=".$item['c_id']));
          }      
          if ($i==1) {
             $html .= '<a href="'.$href.'">'.$item['category'].' <i class="fa fa-caret-down" aria-hidden="true"></i></a>';
             $i=1;
          }else{
            $html .= '<a href="'.$href.'">'.$item['category'].' <i class="fa fa-caret-down" aria-hidden="true"></i></a>';
          }
         
          if(isset($item['childs']) && $item['childs']) { $m++;
            $l4 = 0;
            foreach ($item['childs'] as $item1) {
              if(isset($item1['childs']) && $item1['childs']){
                $l4 = 1;
                // foreach ($item1['childs'] as $item2) {
                //   if(isset($item2['childs']) && $item2['childs']){
                //     $l4 = 1;                    
                //   }
                // }
              }
            }
            if($l4==1){
              // $html .= '<div class="megasub-menu" '.(($m==1)?'style="display: block !important;"':'').'>
              $html .= '<div class="megasub-menu">
              <div class="d_menu drp-menu"><ul class="mega-menu-style mega-menu-mrg-1 pt-0" style="background:#fff;">
                              <div class="container-sm">
                              <div class="row p-2" style="padding-left: 4px !important;">
                                 <div class="menu-megaflex">
                                    <div class="d_in_flex">';
                            $html .=  subMenu1($item['childs'],$item['category'],$item['c_id'],0,'l4'); 
                          $html .= '</div>
                                 </div>
                              </div>
                              </div>
                          </ul></div></div>';
            }else{
              // $html .= '<div class="megasub-menu '.$lc.'" '.(($m==1)?'style="display: block;"':'').'>
              $html .= '<div class="megasub-menu '.$lc.'">
                        <div class="row justify-content-center">
                          <div class="col-lg-10" style="padding-left: 28px;">
                            <div class="row pt-3">';
                            $cc = 0;
                              foreach ($item['childs'] as $item) {
                                //if($cc<=5){
                                  $href = str_replace(" ","-",base_url("products/".url_title(strtolower($item['category']))."/pr?catid=".$item['c_id']));
                                  if($item['image']!=''){
                                    $img = base_url($item['image']);
                                  }else{
                                    $img = base_url('assets/user/images/placeholder-round.png');
                                  }
                        // $html .= '<div class="col-lg-1-8">
                        $html .= '<div class="col-lg-2">
                                    <div class="head_box">
                                      <h6><a href="'.$href.'" style="color:#000;font-weight:500;">'.$item['category'].'</a></h6>
                                    </div>';
                                    if(isset($item['childs']) && $item['childs']){
                          $html .= '<ul>';
                                      foreach ($item['childs'] as $item) {
                                        $href1 = str_replace(" ","-",base_url("products/".url_title(strtolower($item['category']))."/pr?catid=".$item['c_id']));
                                $html .= '<li style="line-height:30px;"><a href="'.$href1.'">'.$item['category'].'</a></li>';
                                      }
                          $html .= '</ul>';
                                    }
                        $html .= '</div>';
                                //}
                                $cc++;
                              }
                    $html .= '</div>
                          </div>
                        </div>
                      </div>';
            }
          }
        $html .= '</div>'; 
      }
      return $html;
  }
}


if (!function_exists('subMenu'))
{
  function subMenu($listOfItems,$parentcat,$parent_id,$m) {
      $html = '';
      $i=1;
      foreach ($listOfItems as $item) {  
        $html .= '<div class="menu_mega '.((isset($item['childs']) && $item['childs'])?'submega_menu':'').'">';
          if(isset($item['childs']) && $item['childs']) { 
            // $href=base_url('category-list/'.url_title(strtolower($parentcat)).'/'.url_title(strtolower($item['category'])).'/'.$item['c_id']);
            $href = str_replace(" ","-",base_url("products/".url_title(strtolower($item['category']))."/pr?catid=".$item['c_id']));
          }else{
            $href = str_replace(" ","-",base_url("products/".url_title(strtolower($item['category']))."/pr?catid=".$item['c_id']));
          }      
          if ($i==1) {
             $html .= '<a href="'.$href.'">'.$item['category'].'</a>';
             $i=1;
          }else{
            $html .= '<a href="'.$href.'">'.$item['category'].'</a>';
          }
          $viewmore = str_replace(" ","-",base_url("category-list/".url_title(strtolower($item['category']))."/".$item['c_id']));
         
            if(isset($item['childs']) && $item['childs']) { $m++;
            $html .= '<div class="megasub-menu mt-2" '.(($m==1)?'style="display: block;"':'').'>
                        <div class="row justify-content-center">
                          <div class="col-lg-8">
                            <div class="row p-5">';
                            $cc = 0;
                              foreach ($item['childs'] as $item) {
                                if($cc<=5){
                                  $href = str_replace(" ","-",base_url("products/".url_title(strtolower($item['category']))."/pr?catid=".$item['c_id']));
                                  if($item['image']!=''){
                                    $img = base_url($item['image']);
                                  }else{
                                    $img = base_url('assets/user/images/placeholder-round.png');
                                  }
                        $html .= '<div class="col-lg-2">
                                    <div class="head_box text-center" style="padding:10px;">
                                      <a href="'.$href.'">
                                        <img src="'.$img.'" alt="images" style="width:100%;padding:10px 0px;">
                                      </a>
                                      <h6>'.$item['category'].'</h6>
                                    </div>
                                  </div>';
                                }
                                /*if($cc==5){
                                  $html .= '<div class="col-lg-2">
                                              <div class="head_box text-center" style="width:100px;height:100px;background:#ddd;padding:30px;border-radius:50px;">
                                                <a href="'.$viewmore.'">
                                                  View More
                                                </a>
                                              </div>
                                            </div>';
                                }*/
                                $cc++;
                              }
                    $html .= '</div>
                          </div>
                        </div>
                      </div>';
            }
        $html .= '</div>'; 
      }
      return $html;
  }
}

if (!function_exists('mobileMenu'))
{
  function mobileMenu($listOfItems) {
       //echo "<pre>";
       //print_r($listOfItems); die;
      $html = '';
      $href = '';
      foreach ($listOfItems as $item) {
        if(isset($item['childs']) && $item['childs']) { 
            $href = str_replace(" ","-",base_url("products/".url_title(strtolower($item['category']))."/pr?catid=".$item['c_id']));
            // $href = str_replace(" ","-",base_url("category-list/".url_title(strtolower($item['category']))."/".$item['c_id']));
        }else{
          $href = str_replace(" ","-",base_url("products/".url_title(strtolower($item['category']))."/pr?catid=".$item['c_id']));
          // $href = str_replace(" ","-",base_url("category-list/".url_title(strtolower($item['category']))."/".$item['c_id']));
        }
        $html .= '<li>
                  <a href="'.$href.'">'.$item['category'].'</a>';
                    if(isset($item['childs']) && $item['childs']) {
                      $html .= '<ul class="mega-menu-style mega-menu-mrg-1">';
                         $html .=  mobileSubMenu($item['childs'],$item['category'],$item['c_id']); 
                      $html .= '</ul>';
                      }
        $html .= '</li>';
      }
      return $html;
  }
}


if (!function_exists('mobileSubMenu'))
{
  function mobileSubMenu($listOfItems,$parentcat,$parent_id) {
      $html = '';
      $i=1;
      foreach ($listOfItems as $item) {  
          if(isset($item['childs']) && $item['childs']) { 
              // $href=base_url('category-list/'.url_title(strtolower($parentcat)).'/'.url_title(strtolower($item['category'])).'/'.$item['c_id']);
              $href = str_replace(" ","-",base_url("products/".url_title(strtolower($item['category']))."/pr?catid=".$item['c_id']));
          }else{
            $href = str_replace(" ","-",base_url("products/".url_title(strtolower($item['category']))."/pr?catid=".$item['c_id']));
          }      
          $html .= '<li>';
          if ($i==1) {
             $html .= '<a class="dropdown-title" href="'.$href.'">'.$item['category'].'</a>';
             $i=1;
          }else{
            $html .= '<a class="dropdown-title" href="'.$href.'">'.$item['category'].'</a>';
          }
            if(isset($item['childs']) && $item['childs']) {
              $html .= '<ul class="mega-menu-style mega-menu-mrg-1">';
                 $html .=  mobileSubMenu($item['childs'],$item['category'],$item['c_id']); 
              $html .= '</ul>';
            }
           /*if(isset($item['childs']) && $item['childs']) {
            $html .= '<ul>';
            foreach ($item['childs'] as $item) {
              $href = str_replace(" ","-",base_url("products/".url_title(strtolower($item['category']))."/pr?catid=".$item['c_id']));
             $html .= '<li><a href="'.$href.'">'.$item['category'].'</a></li>';
            }
             
              $html .= '</li>';
            $html .= '</ul>';
          }*/
          $html .= '</li>';
        }

      return $html;
  }
}


if (!function_exists('catMenu'))
{
  function catMenu($listOfItems,$link,$class) {
      $html = '';
      $CI =& get_instance();
      foreach ($listOfItems as $item) {
        if(isset($item['childs']) && $item['childs']) { 
            // if($link==1){
            //     $href=base_url('category-list/'.url_title(strtolower($item['category'])).'/'.$item['c_id']);
            // }else{
            //     $href=base_url('category-list/'.str_replace(' ', '-',$link).'/'.url_title(strtolower($item['category'])).'/'.$item['c_id']);
            // }
            $href = str_replace(" ","-",base_url("products/".url_title(strtolower($item['category']))."/pr?catid=".$item['c_id']));
          }else{
            $href = str_replace(" ","-",base_url("products/".url_title(strtolower($item['category']))."/pr?catid=".$item['c_id']));
          } 
          $href = str_replace(" ","-",base_url("products/".url_title(strtolower($item['category']))."/pr?catid=".$item['c_id']));
          $pcount = $CI->db->query('select count(pid) as total from products where product_category regexp "[[:<:]]'.$item['c_id'].'[[:>:]]"')->result_array();
        $html .= '<li class="'.$class.'">
                    <a href="'.$href.'">'.$item['category'].' ('.$pcount[0]['total'].')</a>';
                      if(isset($item['childs']) && $item['childs']) {
                        $html .= '<span><a style="cursor:pointer;" data-toggle="collapse" href="#list_'.$item['c_id'].'"><i class="fa fa-chevron-circle-down"></i></a></span>';
                      }
            $html .='<ul id="list_'.$item['c_id'].'" class="collapse" style="list-style-type:disc;margin-left:50px;">';
                          if(isset($item['childs']) && $item['childs']) {
                                $html .=  catMenu($item['childs'],$item['c_id'],$item['category'],'child');
                          }
            $html .= '</ul>
                  </li>';
      }

      return $html;
  }
}



// ------------------------------------------------------------------------

/* End of file translate_helper.php */

/* Location: ./system/helpers/translate_helper.php */