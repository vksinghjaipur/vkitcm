<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:o="urn:schemas-microsoft-com:office:office" style="width:100%;font-family:'Rubik', sans-serif;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;padding:0;Margin:0">
 <head> 
  <meta charset="UTF-8"> 
  <meta content="width=device-width, initial-scale=1" name="viewport"> 
  <meta name="x-apple-disable-message-reformatting"> 
  <meta http-equiv="X-UA-Compatible" content="IE=edge"> 
  <meta content="telephone=no" name="format-detection"> 
  <title><?php echo author; ?></title> 
  <link href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i" rel="stylesheet"> 
  <style type="text/css">
#outlook a {
    padding:0;
}
.ExternalClass {
    width:100%;
}
.ExternalClass,
.ExternalClass p,
.ExternalClass span,
.ExternalClass font,
.ExternalClass td,
.ExternalClass div {
    line-height:100%;
}
.es-button {
    mso-style-priority:100!important;
    text-decoration:none!important;
}
a[x-apple-data-detectors] {
    color:inherit!important;
    text-decoration:none!important;
    font-size:inherit!important;
    font-family:inherit!important;
    font-weight:inherit!important;
    line-height:inherit!important;
}
.es-desk-hidden {
    display:none;
    float:left;
    overflow:hidden;
    width:0;
    max-height:0;
    line-height:0;
    mso-hide:all;
}
[data-ogsb] .es-button {
    border-width:0!important;
    padding:10px 20px 10px 20px!important;
}
[data-ogsb] .es-button.es-button-1 {
    padding:10px 25px!important;
}

</style> 
 </head> 
 <body style="width:100%;font-family:'Rubik', sans-serif;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;padding:0;Margin:0"> 
  <div class="es-wrapper-color" style="background-color:#F6F6F6"> 
   <!--[if gte mso 9]>
            <v:background xmlns:v="urn:schemas-microsoft-com:vml" fill="t">
                <v:fill type="tile" color="#f6f6f6"></v:fill>
            </v:background>
        <![endif]--> 
   <table class="es-wrapper" width="100%" cellspacing="0" cellpadding="0" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;padding:0;Margin:0;width:100%;height:100%;background-repeat:repeat;background-position:center top"> 
     <tr style="border-collapse:collapse"> 
      <td valign="top" style="padding:20px;Margin:0"> 
       <table cellpadding="0" cellspacing="0" class="es-content" align="center" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;table-layout:fixed !important;width:100%"> 
         <tr style="border-collapse:collapse"> 
          <td align="center" style="padding:0;Margin:0"> 
           <table class="es-content-body" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;background-color:transparent;width:600px" cellspacing="0" cellpadding="0" align="center"> 
             <tr style="border-collapse:collapse"> 
              <td align="left" style="Margin:0;padding-top:15px;padding-bottom:15px;padding-left:40px;padding-right:40px;background: #fff;"> 
               <table cellspacing="0" cellpadding="0" width="100%" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px"> 
                 <tr style="border-collapse:collapse"> 
                  <td align="left" style="padding:0;Margin:0;width:560px"> 
                   <table width="100%" cellspacing="0" cellpadding="0" role="presentation" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px"> 
                     <tr style="border-collapse:collapse"> 
                      <td class="made_with" align="left" style="padding:0;Margin:0;font-size:0"><a target="_blank" href="<?php echo base_url(); ?>" style="-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;text-decoration:underline;color:#9AAEA6;font-size:14px"><img src="<?php echo base_url(email_logo); ?>" alt width="120" style="display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic"></a></td> 
                      <td class="made_with" align="right" style="padding:0;Margin:0;font-size:0">
                        <p><a target="_blank" href="<?php echo base_url(); ?>" style="-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;text-decoration:underline;color:#666666;font-size:16px;text-decoration:none;">Order ID : <?php echo $invoice_no; ?></a></p>
                        <p><a target="_blank" href="<?php echo base_url(); ?>" style="-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;text-decoration:underline;color:#666666;font-size:16px;text-decoration:none;">TXN ID : <?php echo $txn_id; ?></a></p>
                        </td>
                     </tr> 
                   </table></td> 
                 </tr> 
               </table></td> 
             </tr> 
           </table></td> 
         </tr> 
       </table> 
       <table class="es-content" cellspacing="0" cellpadding="0" align="center" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;table-layout:fixed !important;width:100%"> 
         <tr style="border-collapse:collapse"> 
          <td align="center" style="padding:0;Margin:0"> 
           <table class="es-content-body" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;background-color:#ffffff;width:600px" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center"> 
             <tr style="border-collapse:collapse"> 
              <td align="left" style="Margin:0;padding-top:0px;padding-bottom:40px;padding-left:40px;padding-right:40px"> 
                <h1 style="Margin:0;line-height:48px;mso-line-height-rule:exactly;font-family:'Rubik', sans-serif;font-size:20px;font-style:normal;font-weight:normal;color:#666666">Order Summary</h1>
                <table width="100%" cellspacing="0" cellpadding="0" style="max-width:600px;">

                  <tbody>

                      <?php $grandtotal = $shipping = array(); 

                          foreach ($cart as $key => $value) : 

                              //$grandtotal[] = $value['subtotal']; 

                              //$shipping[] = ($value["options"]["amount"]*$value['qty']); 

                              $price = 0;
                              $pcoupon_amount = 0;
                              if(isset($coupon_apply) && $coupon_apply){
                                $coupon_apply = $this->session->userData('product_coupon');
                                if(isset($coupon_apply[$value['id']]) && $coupon_apply[$value['id']]){
                                  if($coupon_apply[$value['id']]['coupon_type']==0){
                                    $pcoupon_amount = $coupon_apply[$value['id']]['coupon_amount'];
                                  }else{
                                    $pcoupon_amount = ($value['price']*$coupon_apply[$value['id']]['coupon_amount'])/100;
                                  }
                                  $price = (($value['price']*$value["qty"])-$pcoupon_amount);
                                  $apply = 1;
                                }else{
                                  $apply = 0;
                                }
                              }else{
                                $price = (($value['price']*$value["qty"]));
                                $apply = 0;
                              }

                              $amount[] = $price;

                      ?>

                      <tr>

                          <td valign="top" align="center" width="350" style="background-color:#ffffff">

                              <table border="0" cellspacing="0" cellpadding="0" width="100%">

                                  <tbody>

                                      <tr>

                                          <td width="40%" style="padding-left:20px;text-align:center" valign="middle" align="center">

                                              <a style="text-decoration:none" href="" target="_blank">

                                                  <img border="0" style="width: 75px" src="<?php echo base_url(str_replace(' ','%20',$value['options']['product_photos'])); ?>" class="CToWUd">

                                              </a>

                                          </td>

                                          <td width="60%" align="center" valign="top" style="padding:12px 15px 0 10px;margin:0;vertical-align:top;min-width:100px">

                                              <p style="padding:0;margin:0"> 
                                                  <a style="text-decoration:none;color:#565656" href="" target="_blank"><span style="color:#565656;font-size:13px"><?php echo $value["options"]["product_name"]; ?></span></a> 
                                              </p>

                                          </td>

                                      </tr>

                                  </tbody>

                              </table>

                          </td>

                          <td valign="top" align="center" width="250" style="background-color:#ffffff">

                              <table border="0" cellspacing="0" cellpadding="0" width="100%">

                                  <tbody>

                                      <tr>

                                          <td width="33%" valign="top" align="center" style="padding:12px 10px 0 10px;margin:0;text-align:center">

                                              <p style="white-space:nowrap;padding:0;margin:0;color:#848484;font-size:12px">Item Price</p>

                                              <p style="white-space:nowrap;margin:0;padding:7px 0 0 0;color:#565656;font-size:13px">
                                                <?php if($value['options']['shop_rewards']==0){ ?>
                                                  S$ <?php echo number_format($value['price'], 2, '.', ''); ?>
                                                <?php }else{ ?>
                                                  <?php echo ($value['price']*$value["qty"]); ?> Points
                                                <?php } ?>
                                              </p>
                                              <p style="white-space:nowrap;margin:0;padding:7px 0 0 0;color:#565656;font-size:13px">
                                                <?php if($apply==1){ ?>
                                                  Coupon Amount : <span class="price text-danger">$<?php echo number_format(($pcoupon_amount),2); ?></span>
                                                <?php } ?>
                                              </p>

                                          </td>

                                          <td width="33%" valign="top" align="center" style="padding:12px 10px 0 10px;margin:0;text-align:center">
                                              <?php if($value['options']['shop_rewards']==0){ ?>
                                                <p style="padding:0;margin:0;color:#848484;font-size:12px">Qty</p>
                                                <p style="padding:7px 0 0 0;margin:0;color:#565656;font-size:13px"><?php echo $value['qty']; ?></p>
                                              <?php }else{ ?>
                                                <p>&nbsp;</p>
                                                <p>&nbsp;</p>
                                              <?php } ?>

                                          </td>

                                          <td width="33%" valign="top" align="center" style="padding:12px 20px 0 10px;margin:0;text-align:center">

                                              <p style="white-space:nowrap;padding:0;margin:0;color:#848484;font-size:12px">Subtotal</p>

                                              <p style="white-space:nowrap;padding:7px 0 0 0;margin:0;color:#565656;font-size:13px">
                                                S$ <?php echo number_format($price, 2, '.', ''); ?>
                                              </p>

                                          </td>

                                      </tr>

                                  </tbody>

                              </table>

                          </td>

                      </tr>

                  <?php endforeach; ?>

                  </tbody>

                </table>
              <?php 
                  $Subtotal = array_sum($grandtotal);
                  $cart_amount = array_sum($amount);
              ?>

              <table width="100%" cellspacing="0" cellpadding="0" style="max-width:600px;">

                  <tbody>

                      <tr>

                          <td align="right" valign="top" style="background-color:#ffffff;display:block;margin:0 auto;clear:both;padding:5px 20px 0 20px" bgcolor="">

                              <table border="0" cellspacing="0" cellpadding="0" width="100%" style="margin:0">

                                  <tbody>

                                      <tr>

                                          <td colspan="4" align="right" valign="top" style="padding:10px 0 0 0">

                                              <p style="text-align:right;padding:0;margin:0;color:#565656;font-size:13px">

                                                  Sub Total S$ 
                                                  <span style="font-size:21px">
                                                      <?php echo number_format($cart_amount, 2, '.', ''); ?>
                                                  </span>

                                              </p>

                                          </td>

                                      </tr>
                                      <?php if($coupon!=0){ ?>
                                      <tr>

                                          <td colspan="4" align="right" valign="top" style="padding:10px 0 0 0">

                                              <p style="text-align:right;padding:0;margin:0;color:#565656;font-size:13px">
                                                  Coupon Amount S$ <span style="font-size:21px"> - <?php echo number_format($coupon, 2, '.', ''); ?></span>

                                              </p>

                                          </td>

                                      </tr>
                                      <?php } ?>
                                      <?php if(isset($ship_charge) && $ship_charge!='' && $ship_charge>0){ ?>
                                          <tr>

                                              <td colspan="4" align="right" valign="top" style="padding:10px 0 0 0">

                                                  <p style="text-align:right;padding:0;margin:0;color:#565656;font-size:13px">

                                                      Shipping Amount S$ <span style="font-size:21px"> <?php echo number_format($ship_charge, 2, '.', ''); ?></span>

                                                  </p>

                                              </td>

                                          </tr>
                                      <?php }else{$ship_charge=0;} ?>
                                      <?php if(isset($birthday) && $birthday!='' && $birthday>0){ ?>
                                          <tr>

                                              <td colspan="4" align="right" valign="top" style="padding:10px 0 0 0">

                                                  <p style="text-align:right;padding:0;margin:0;color:#565656;font-size:13px">

                                                      Birthday Month Discount S$ <span style="font-size:21px"> <?php echo number_format($birthday, 2, '.', ''); ?></span>

                                                  </p>

                                              </td>

                                          </tr>
                                      <?php }else{$birthday=0;} ?>

                                  </tbody>

                              </table>

                          </td>

                      </tr>

                  </tbody>

              </table>

              <table width="100%" cellspacing="0" cellpadding="0" style="max-width:600px;">

                  <tbody>

                      <tr>

                          <td valign="top" align="right" bgcolor="" style="clear:both;display:block;margin:0 auto;padding:10px 20px 0 20px;background-color:#ffffff">

                              <table cellspacing="0" cellpadding="0" width="100%">

                                  <tbody>

                                      <tr>

                                          <td bgcolor="#f9f9f9" valign="top" align="right" style="border-top:2px solid #565656;border-bottom:1px solid #e6e6e6;padding:15px 0;margin:0;background-color:#f9f9f9">

                                              <p style="padding:0;margin:0;text-align:right;color:#565656;line-height:22px;white-space:nowrap;font-size:13px">

                                                  Amount Paid S$ <span style="font-size:21px"> <?php echo number_format(($cart_amount-$coupon-$firstorder+$ship_charge-$birthday),2); ?></span>
                                              </p>

                                          </td>

                                      </tr>

                                  </tbody>

                              </table>

                          </td>

                      </tr>

                  </tbody>

              </table>

              <table width="100%" cellspacing="0" cellpadding="0" style="max-width:600px;">

                  <tbody>

                      <tr>

                          <td valign="top" align="left" style="background-color:#ffffff;color:#2c2c2c;display:block;font-weight:300;margin:0;padding:0;clear:both" bgcolor="#ffffff">

                              <table width="100%" cellspacing="0" cellpadding="0">

                                  <tbody>

                                      <tr>

                                          <td valign="top" align="left" style="padding:20px 20px 0 20px;margin:0">

                                              <p style="margin:0;padding:0;color:#565656;font-size:13px">DELIVERY DETAIL:</p>

                                              <p style="padding:0;margin:15px 0 10px 0;font-size:15px;color:#333333;line-height:25px;">

                                                  <?php echo "Name - ".$address['sname'].",<br> Mobile No. - ".$address['smobile_no']."<br>"; ?>

                                                  <?php if(isset($address['semail']) && $address['semail']!=''){ echo "Email - ".$address['semail']."<br>"; } ?>

                                                  <?php if(isset($address['saddress1']) && $address['saddress1']!=''){ echo "Address - ".$address['saddress1']."<br>"; } ?>
                                                  <?php if(isset($address['saddress2']) && $address['saddress2']!=''){ echo "Building Name - ".$address['saddress2']."<br>"; } ?>

                                                  <!-- <?php //if(isset($address['scountry']) && $address['scountry']!=''){echo "Country - ".$address['scountry'].",<br>"; } ?>  -->

                                                  <?php //echo "City - ".$address['scity'].",<br>"; ?> 

                                                  <?php //echo "State - ".$address['sstate'].",<br>"; ?> 

                                                  <?php if(isset($address['spincode']) && $address['spincode']!=''){ echo "Postal Code - ".$address['spincode']; } ?>

                                              </p>

                                          </td>

                                      </tr>

                                  </tbody>

                              </table>

                          </td>

                      </tr>

                  </tbody>

              </table>
              </td> 
             </tr> 
           </table></td> 
         </tr> 
       </table> 
       <table cellpadding="0" cellspacing="0" class="es-footer" align="center" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;table-layout:fixed !important;width:100%;background-color:transparent;background-repeat:repeat;background-position:center top"> 
         <tr style="border-collapse:collapse"> 
          <td align="center" style="padding:0;Margin:0;"> 
           <table class="es-footer-body" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;background-color:#fff;width:600px" cellspacing="0" cellpadding="0" align="center" bgcolor="#fff">
             <tr>
               <td align="center">
                  <a href="<?php echo base_url(); ?>admin/order-list" style="color:#fff;padding:5px 15px;text-align:center;background-color:#FF770E;border-color:#FF770E;text-decoration:none;">View Order</a>
               </td>
             </tr>
           </table>
           <table class="es-footer-body" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;background-color:#666666;width:600px" cellspacing="0" cellpadding="0" align="center" bgcolor="#666666"> 
             <tr style="border-collapse:collapse"> 
              <td align="left" style="padding:0;Margin:0"> 
               <table width="100%" cellspacing="0" cellpadding="0" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px"> 
                 <tr style="border-collapse:collapse"> 
                  <td valign="top" align="center" style="padding:0;Margin:0;width:600px"> 
                   <table width="100%" cellspacing="0" cellpadding="0" role="presentation" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
                     <tr style="border-collapse:collapse"> 
                      <td esdev-links-color="#666666" align="center" class="es-m-txt-с" style="padding:0;Margin:0;padding-top:15px;padding-bottom:15px"><p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'Rubik', sans-serif;line-height:18px;color:#fff;font-size:12px">Copyright <?php echo date('Y'); ?> © <?php echo author; ?>.  All rights reserved.</p></td> 
                     </tr> 
                   </table></td> 
                 </tr> 
               </table></td> 
             </tr> 
           </table></td> 
         </tr> 
       </table></td> 
     </tr> 
   </table> 
  </div>  
 </body>
</html>