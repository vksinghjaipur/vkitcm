    <div class="wrapper  theme-5-active pimary-color-green">

		<!-- Top Menu Items -->

		<nav class="navbar navbar-inverse navbar-fixed-top">

			<div class="mobile-only-brand pull-left" style="padding-left:0px;">

				<div class="nav-header pull-left pl-0"  style="display: flex; align-items: center;">

					<div class="logo-wrap" style="padding-top:0px;">

						<a href="<?php echo base_url(A); ?>">

							<img class="brand-img" src="<?php echo base_url(admin_logo) ?>" alt="brand" style="width:32%;">

						</a>

					</div>

				</div>	

				<a id="toggle_nav_btn" class="toggle-left-nav-btn inline-block ml-20 pull-left" href="javascript:void(0);"><i class="zmdi zmdi-menu"></i></a>

				<!-- <a id="toggle_mobile_search" data-toggle="collapse" data-target="#search_form" class="mobile-only-view" href="javascript:void(0);"><i class="zmdi zmdi-search"></i></a> -->

				<!-- <a id="toggle_mobile_nav" class="mobile-only-view" href="javascript:void(0);"><i class="zmdi zmdi-more"></i></a> -->
				<a class="inline-block ml-30 hidden-sm pull-left btn btn-success mt-15" href="<?php echo base_url(A.'/add-product'); ?>"><i class="fa fa-plus"></i> Add Product</a>

			</div>

			<div id="mobile_only_nav" class="mobile-only-nav pull-right">

				<ul class="nav navbar-right top-nav pull-right">

					<li class="dropdown auth-drp">

						<a href="#" class="dropdown-toggle pr-0" data-toggle="dropdown"><img src="https://www.w3schools.com/howto/img_avatar.png" class="user-image" width="100%"> <?php echo author; ?></a>

						<ul class="dropdown-menu user-auth-dropdown" data-dropdown-in="flipInX" data-dropdown-out="flipOutX">
							<li class="divider"></li>
							<li>
								<a href="<?php echo base_url(A.'-logout'); ?>"><i class="zmdi zmdi-power"></i><span>Log Out</span></a>
							</li>
						</ul>
					</li>

				</ul>

			</div>	

		</nav>

		<!-- /Top Menu Items -->

		

		<!-- Left Sidebar Menu -->

		<div class="fixed-sidebar-left">

			<ul class="nav navbar-nav side-nav nicescroll-bar">

				<li>

					<a class="<?php echo(uri_string()==A)?'active':''; ?>" href="<?php echo base_url(A); ?>">

						<div class="pull-left"><i class="zmdi zmdi-landscape mr-20"></i>

							<span class="right-nav-text">Dashboard</span>

						</div>
						<div class="clearfix"></div>
					</a>

				</li>
				<li>
					<a class="<?php echo(uri_string()==A.'/web-setting')?'active':''; ?>" href="<?php echo base_url(A.'/web-setting'); ?>">
						<div class="pull-left"><i class="icon-settings mr-20"></i>
							<span class="right-nav-text">Setting</span>
						</div>
						<div class="clearfix"></div>
					</a>
				</li>
		        <!-- <li>      
		           <a class="<?php //echo(uri_string()==A.'/add-brand')?'active':''; ?>" href="<?php //echo base_url(A."/add-brand"); ?>">
		            <div class="pull-left"><i class="icon-flag mr-20"></i>
		              <span class="right-nav-text">Brand</span>
		            </div>         
		            <div class="clearfix"></div>         
		           </a>        
		        </li> -->
				<li>
					<a class="<?php echo(uri_string()==A.'/add-category' || uri_string()==A.'/all-category')?'active':''; ?>" href="javascript:void(0);" data-toggle="collapse" data-target="#ecom_dr"><div class="pull-left"><i class="zmdi zmdi-apps mr-20"></i><span class="right-nav-text">Categories</span></div><div class="pull-right"><i class="fa fa-chevron-down"></i></div>
						<div class="clearfix"></div>
					</a>
					<ul id="ecom_dr" class="collapse collapse-level-1 <?php echo(uri_string()==A.'/add-category' || uri_string()==A.'/all-category')?'in':''; ?>">
						<?php if($this->admin_type=='superadmin' || (in_array('1.1', $this->authority))){ ?>
							<li>
								<a href="<?php echo base_url(A.'/add-category'); ?>">Add New</a>
							</li>
						<?php } ?>
						<?php if($this->admin_type=='superadmin' || (in_array('1.2', $this->authority))){ ?>
							<li>
								<a href="<?php echo base_url(A.'/all-category'); ?>">Category List</a>
							</li>
						<?php } ?>
					</ul>
				</li>
				<li>
					<a class="<?php echo(uri_string()==A.'/add-product' || uri_string()==A.'/product-list')?'active':''; ?>" href="javascript:void(0);" data-toggle="collapse" data-target="#addbooking">
						<div class="pull-left"><i class="zmdi zmdi-collection-item mr-20"></i> <span class="right-nav-text">Products</span></div><div class="pull-right"><i class="fa fa-chevron-down"></i></div>
						<div class="clearfix"></div>
					</a>
					<ul id="addbooking" class="collapse collapse-level-1 <?php echo(uri_string()==A.'/add-product' || uri_string()==A.'/product-list')?'in':''; ?>">
						<?php if($this->admin_type=='superadmin' || (in_array('3.1', $this->authority))){ ?>
							<li>
								<a href="<?php echo base_url(A.'/add-product'); ?>">Add Product</a>
							</li>
						<?php } ?>
						<?php if($this->admin_type=='superadmin' || (in_array('3.2', $this->authority))){ ?>
							<li>
								<a href="<?php echo base_url(A.'/product-list'); ?>">Products List</a>
							</li>
						<?php } ?>
					</ul>
				</li>
				<li>
					<a class="<?php echo(uri_string()==A.'/order-list' || uri_string()==A.'/cancle-order-list')?'active':''; ?>" href="javascript:void(0);" data-toggle="collapse" data-target="#order">
						<div class="pull-left"><i class="icon-list mr-20"></i><span class="right-nav-text">Orders</span></div><div class="pull-right"><i class="fa fa-chevron-down"></i></div>
						<div class="clearfix"></div>
					</a>
					<ul id="order" class="collapse collapse-level-1 <?php echo(uri_string()==A.'/order-list' || uri_string()==A.'/cancle-order-list')?'in':''; ?>">
						<?php if($this->admin_type=='superadmin' || (in_array('4.1', $this->authority))){ ?>
							<li>
								<a href="<?php echo base_url(A.'/order-list'); ?>">All Orders</a>
							</li>
						<?php } ?>
						<?php if($this->admin_type=='superadmin' || (in_array('4.2', $this->authority))){ ?>
							<li>
								<a href="<?php echo base_url(A.'/cancle-order-list'); ?>">Cancel Orders</a>
							</li>
						<?php } ?>
					</ul>
				</li>
				<li>
					<a href="<?php echo base_url(A."/coupon-list"); ?>">
						<div class="pull-left"><i class="icon-tag mr-20"></i>
							<span class="right-nav-text">Coupon</span>
						</div>
						<div class="clearfix"></div>
					</a>
				</li>
				<li>
					<a class="<?php echo(uri_string()==A.'/user-list')?'active':''; ?>" href="<?php echo base_url(A."/user-list"); ?>">
						<div class="pull-left"><i class="zmdi zmdi-accounts-outline mr-20"></i>
							<span class="right-nav-text">Users</span>
						</div>
						<div class="clearfix"></div>
					</a>
				</li>
				<li>
					<a class="<?php echo(uri_string()==A.'/add-slider-banner')?'active':''; ?>" href="javascript:void(0);" data-toggle="collapse" data-target="#addbanner"><div class="pull-left"><i class="zmdi zmdi-collection-image mr-20"></i><span class="right-nav-text">Banner</span></div><div class="pull-right"><i class="fa fa-chevron-down"></i></div>
						<div class="clearfix"></div>
					</a>
					<ul id="addbanner" class="collapse collapse-level-1">
						<li>
							<a href="<?php echo base_url(A.'/add-slider-banner'); ?>">Slider Banner</a>
						</li>
					</ul>
				</li>
		      	<li>
			        <a class="<?php echo(uri_string()==A.'/add-article-category' || uri_string()==A.'/add-article' || uri_string()==A.'/all-article')?'active':''; ?>" href="javascript:void(0);" data-toggle="collapse" data-target="#article">
			            <div class="pull-left"><i class="zmdi zmdi-account-box-o mr-20"></i><span class="right-nav-text">Articles</span></div>
			            <div class="pull-right"><i class="fa fa-chevron-down"></i></div>
			            <div class="clearfix"></div>
			        </a>
			        <ul id="article" class="collapse collapse-level-1 <?php echo(uri_string()==A.'/add-article-category' || uri_string()==A.'/add-article' || uri_string()==A.'/all-article')?'in':''; ?>">
			         	<?php if($this->admin_type=='superadmin' || (in_array('5.1', $this->authority))){ ?>
				            <li>
				               <a href="<?php echo base_url(A.'/add-article-category'); ?>">Category</a>
				            </li>
				        <?php } ?>
				        <?php if($this->admin_type=='superadmin' || (in_array('5.5', $this->authority))){ ?>
				            <li>
				               <a href="<?php echo base_url(A.'/add-article'); ?>">Add New</a>
				            </li>
				        <?php } ?>
				        <?php if($this->admin_type=='superadmin' || (in_array('5.6', $this->authority))){ ?>
				            <li>
				               <a href="<?php echo base_url(A.'/all-article'); ?>">All List</a>
				            </li>
				        <?php } ?>
			        </ul>
		      	</li>
				<?php /* ?>
			    <li>
			         <a class="<?php echo(uri_string()==A.'/faq-category' || uri_string()==A.'/add-faq' || uri_string()==A.'/all-faq')?'active':''; ?>" href="javascript:void(0);" data-toggle="collapse" data-target="#faqs">
			            <div class="pull-left"><i class="zmdi zmdi-comment-alert mr-20"></i><span class="right-nav-text">FAQ</span></div>
			            <div class="pull-right"><i class="fa fa-chevron-down"></i></div>
			            <div class="clearfix"></div>
			         </a>
			         <ul id="faqs" class="collapse collapse-level-1">
			         	<!-- <li>
			               <a href="<?php //echo base_url(A.'/faq-category'); ?>">Category</a>
			            </li> -->
			            <li>
			               <a href="<?php echo base_url(A.'/add-faq'); ?>">Add New</a>
			            </li>
			            <li>
			               <a href="<?php echo base_url(A.'/all-faq'); ?>">All List</a>
			            </li>
			         </ul>
		      	</li>
		      	<li>
			         <a class="<?php echo((uri_string()==A.'/add-nationality') || (uri_string()==A.'/add-language') || (uri_string()==A.'/add-maid') || uri_string()==A.'/all-maid')?'active':''; ?>" href="javascript:void(0);" data-toggle="collapse" data-target="#maid">
			            <div class="pull-left"><i class="zmdi zmdi-accounts mr-20"></i><span class="right-nav-text">Maids</span></div>
			            <div class="pull-right"><i class="fa fa-chevron-down"></i></div>
			            <div class="clearfix"></div>
			         </a>
			         <ul id="maid" class="collapse collapse-level-1">
			            <li>
			               <a href="<?php echo base_url(A.'/add-nationality'); ?>">Nationality</a>
			            </li>
			            <li>
			               <a href="<?php echo base_url(A.'/add-language'); ?>">Language</a>
			            </li>
			            <li>
			               <a href="<?php echo base_url(A.'/add-maid'); ?>">Add New</a>
			            </li>
			            <li>
			               <a href="<?php echo base_url(A.'/all-maids'); ?>">All List</a>
			            </li>
			         </ul>
		      	</li>
		      	<li>
			         <a class="<?php echo((uri_string()==A.'/add-testimonial') || uri_string()==A.'/all-testimonial')?'active':''; ?>" href="javascript:void(0);" data-toggle="collapse" data-target="#testimonial">
			            <div class="pull-left"><i class="zmdi zmdi-info mr-20"></i><span class="right-nav-text">Testimonials</span></div>
			            <div class="pull-right"><i class="fa fa-chevron-down"></i></div>
			            <div class="clearfix"></div>
			         </a>
			         <ul id="testimonial" class="collapse collapse-level-1">
			            <li>
			               <a href="<?php echo base_url(A.'/add-testimonial'); ?>">Add New</a>
			            </li>
			            <li>
			               <a href="<?php echo base_url(A.'/all-testimonials'); ?>">All List</a>
			            </li>
			         </ul>
		      	</li>
		      	<li>
			         <a class="<?php echo((uri_string()==A.'/add-team') || uri_string()==A.'/all-team')?'active':''; ?>" href="javascript:void(0);" data-toggle="collapse" data-target="#team">
			            <div class="pull-left"><i class="zmdi zmdi-accounts mr-20"></i><span class="right-nav-text">Our Team</span></div>
			            <div class="pull-right"><i class="fa fa-chevron-down"></i></div>
			            <div class="clearfix"></div>
			         </a>
			         <ul id="team" class="collapse collapse-level-1">
			            <li>
			               <a href="<?php echo base_url(A.'/add-team'); ?>">Add New</a>
			            </li>
			            <li>
			               <a href="<?php echo base_url(A.'/all-teams'); ?>">All List</a>
			            </li>
			         </ul>
		      	</li>
				<li>
			         <a class="<?php echo((uri_string()==A.'/add-logo') || uri_string()==A.'/all-logos')?'active':''; ?>" href="javascript:void(0);" data-toggle="collapse" data-target="#logos">
			            <div class="pull-left"><i class="zmdi zmdi-image mr-20"></i><span class="right-nav-text">Accreditation Logos</span></div>
			            <div class="pull-right"><i class="zmdi zmdi-caret-down"></i></div>
			            <div class="clearfix"></div>
			         </a>
			         <ul id="logos" class="collapse collapse-level-1">
			            <li>
			               <a href="<?php echo base_url(A.'/add-logo'); ?>">Add New</a>
			            </li>
			            <li>
			               <a href="<?php echo base_url(A.'/all-logos'); ?>">All Logo</a>
			            </li>
			         </ul>
		      	</li>
				<li>
			         <a class="<?php echo((uri_string()==A.'/add-credential') || uri_string()==A.'/all-credentials')?'active':''; ?>" href="javascript:void(0);" data-toggle="collapse" data-target="#credentials">
			            <div class="pull-left"><i class="zmdi zmdi-image mr-20"></i><span class="right-nav-text">Our Credential</span></div>
			            <div class="pull-right"><i class="zmdi zmdi-caret-down"></i></div>
			            <div class="clearfix"></div>
			         </a>
			         <ul id="credentials" class="collapse collapse-level-1">
			            <li>
			               <a href="<?php echo base_url(A.'/add-credential'); ?>">Add New</a>
			            </li>
			            <li>
			               <a href="<?php echo base_url(A.'/all-credentials'); ?>">All Credentials</a>
			            </li>
			         </ul>
		      	</li>
			    <li>
			         <a class="<?php echo((uri_string()==A.'/add-learning-resources') || uri_string()==A.'/all-learning-resources')?'active':''; ?>" href="javascript:void(0);" data-toggle="collapse" data-target="#learningresourcess">
			            <div class="pull-left"><i class="zmdi zmdi-layers mr-20"></i><span class="right-nav-text">Learning Resources</span></div>
			            <div class="pull-right"><i class="fa fa-chevron-down"></i></div>
			            <div class="clearfix"></div>
			         </a>
			         <ul id="learningresourcess" class="collapse collapse-level-1">
			            <li>
			               <a href="<?php echo base_url(A.'/add-learning-resources'); ?>">Add New</a>
			            </li>
			            <li>
			               <a href="<?php echo base_url(A.'/all-learning-resources'); ?>">All List</a>
			            </li>
			         </ul>
		      	</li>
		      	<li>
					<a class="<?php echo((uri_string()==A.'/gallery-category') || (uri_string()==A.'/add-gallery') || (uri_string()==A.'/all-gallery'))?'active':''; ?>" href="javascript:void(0);" data-toggle="collapse" data-target="#gallery"><div class="pull-left"><i class="zmdi zmdi-apps mr-20"></i><span class="right-nav-text">Project Gallery</span></div><div class="pull-right"><i class="fa fa-chevron-down"></i></div>
						<div class="clearfix"></div>
					</a>
					<ul id="gallery" class="collapse collapse-level-1">
						<li>
			               <a href="<?php echo base_url(A.'/gallery-category'); ?>">Category</a>
			            </li>
						<li>
							<a href="<?php echo base_url(A.'/add-gallery'); ?>">Add Project & Images</a>
						</li>
						<li>
							<a href="<?php echo base_url(A.'/all-gallery-projects'); ?>">All Projects</a>
						</li>
					</ul>
				</li>
		      	<li>
					<a class="<?php echo((uri_string()==A.'/add-interactive-gallery') || (uri_string()==A.'/all-interactive-gallery'))?'active':''; ?>" href="javascript:void(0);" data-toggle="collapse" data-target="#interactive"><div class="pull-left"><i class="zmdi zmdi-apps mr-20"></i><span class="right-nav-text">Interactive Gallery</span></div><div class="pull-right"><i class="fa fa-chevron-down"></i></div>
						<div class="clearfix"></div>
					</a>
					<ul id="interactive" class="collapse collapse-level-1">
						<li>
							<a href="<?php echo base_url(A.'/add-interactive-gallery'); ?>">Add Images</a>
						</li>
						<li>
							<a href="<?php echo base_url(A.'/all-interactive-gallery'); ?>">All Images</a>
						</li>
					</ul>
				</li>
				<?php */ ?>

				<?php /* ?>
					<!-- <li>
						<a class="<?php //echo(uri_string()==A.'/newsletter-list')?'active':''; ?>" href="<?php //echo base_url(A."/newsletter-list"); ?>">
							<div class="pull-left"><i class="icon-bell mr-20"></i>
								<span class="right-nav-text">Newsletter Subscriber</span>
							</div>
							<div class="clearfix"></div>
						</a>
					</li> -->
					<!-- <li>
						<a href="<?php //echo base_url(A."/rewards-point"); ?>">
							<div class="pull-left"><i class="icon-badge mr-20"></i>
								<span class="right-nav-text">Rewards Point</span>
							</div>
							<div class="clearfix"></div>
						</a>
					</li> -->
					<!-- <li>
						<a class="<?php //echo(uri_string()==A.'/order-report-search')?'active':''; ?>" href="<?php //echo base_url(A."/order-report-search"); ?>">
							<div class="pull-left"><i class="zmdi zmdi-search-for mr-20"></i>
								<span class="right-nav-text">Order Report </span>
							</div>
							<div class="clearfix"></div>
						</a>
					</li> -->
				<?php */ ?>
				

				<li>
					<a href="<?php echo base_url(A.'-logout'); ?>"><div class="pull-left"><i class="zmdi zmdi-chart-donut mr-20"></i><span class="right-nav-text">Logout </span></div><div class="clearfix"></div></a>
				</li>

			</ul>

		</div>

		<!-- /Left Sidebar Menu -->
<style>
	.mce-path-item{display: none;}
	.wrapper.theme-5-active .navbar.navbar-inverse {background:#fff;}
	a.toggle-left-nav-btn i {color:#000;}
	.wrapper.theme-5-active .fixed-sidebar-left .side-nav {background:#fff;}
	.fixed-sidebar-left .side-nav > li > a{color:#000;}
	.fixed-sidebar-left .side-nav li a .pull-right i{color:#000;font-size: 18px;}
	.fixed-sidebar-left .side-nav li:hover{background:#f2f2f2;}
	.navbar.navbar-inverse.navbar-fixed-top .nav-header{border-right: 1px solid #f3f3f3;}
	.card-view{border-radius:20px;}
	.card-view.panel .panel-heading{border-top-left-radius: 20px;border-top-right-radius: 20px;}
	.card-view.panel.panel-default > .panel-heading{background: #dfdfdf;}
	.table > tbody > tr > td, .jsgrid-table > tbody > tr > td, .table > tbody > tr > th, .jsgrid-table > tbody > tr > th, .table > tfoot > tr > td, .jsgrid-table > tfoot > tr > td, .table > tfoot > tr > th, .jsgrid-table > tfoot > tr > th, .table > thead > tr > td, .jsgrid-table > thead > tr > td, .table > thead > tr > th, .jsgrid-table > thead > tr > th{padding:8px;}
	.card-view.panel > .panel-heading{padding-top:10px;padding-bottom:10px;}
	.panel-title{line-height:36px;}
</style>