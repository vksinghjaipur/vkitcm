			<!-- Footer -->

			<footer class="footer container-fluid pl-30 pr-30">

				<div class="row">

					<div class="col-sm-12">

						<p class="no-print"><?php echo date('Y'); ?> &copy; <?php echo author; ?>. All Right Reserved.</p>
						<!-- <p class="print-visible" style="display:none;"><?php //echo date('Y'); ?> &copy; <?php //echo author; ?>. All Right Reserved | Design & Developed by <a href="www.starwebindia.com" target="_blank"> Star Web India</a></p> -->

					</div>

				</div>

			</footer>

		<!-- /Footer -->	

		</div>

		<!-- /Main Content -->

    </div>

    <!-- /#wrapper -->

	

	<!-- JavaScript -->

	

    

    

	<!-- Data table JavaScript -->

	<script src="<?php echo base_url('assets/admin/vendors/bower_components/datatables/media/js/jquery.dataTables.min.js'); ?>"></script>

	

	<!-- Slimscroll JavaScript -->

	<script src="<?php echo base_url('assets/admin/dist/js/jquery.slimscroll.js'); ?>"></script>
	
	<script src="<?php echo base_url('assets/admin/dist/js/drag-arrange.js'); ?>"></script>
	<script src="<?php echo base_url('assets/admin/dist/js/jquery-ui.min.js'); ?>"></script>

	

	<!-- Progressbar Animation JavaScript -->

	<script src="<?php echo base_url('assets/admin/vendors/bower_components/waypoints/lib/jquery.waypoints.min.js'); ?>"></script>

	<script src="<?php echo base_url('assets/admin/vendors/bower_components/jquery.counterup/jquery.counterup.min.js'); ?>"></script>

	<script src="<?php echo base_url('assets/admin/vendors/bower_components/tinymce/tinymce.min.js'); ?>"></script>

	<script src="<?php echo base_url('assets/admin/dist/js/tinymce-data.js'); ?>"></script>



	<script src="<?php echo base_url('assets/admin/vendors/bower_components/select2/dist/js/select2.full.min.js'); ?>"></script>

	<script src="<?php echo base_url('assets/admin/vendors/bower_components/multiselect/js/jquery.multi-select.js'); ?>"></script>



	<script src="<?php echo base_url('assets/admin/vendors/bower_components/bootstrap-select/dist/js/bootstrap-select.min.js'); ?>"></script>

	<script type="text/javascript" src="<?php echo base_url('assets/admin/vendors/bower_components/moment/min/moment-with-locales.min.js'); ?>"></script>

	<script src="<?php echo base_url('assets/admin/vendors/bower_components/mjolnic-bootstrap-colorpicker/dist/js/bootstrap-colorpicker.min.js'); ?>"></script>

	<script type="text/javascript" src="<?php echo base_url('assets/admin/vendors/bower_components/eonasdan-bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js'); ?>"></script>

	<!-- Bootstrap Tagsinput JavaScript -->

	<script src="<?php echo base_url('assets/admin/vendors/bower_components/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js'); ?>"></script>

	

	<!-- Bootstrap Touchspin JavaScript -->

	<script src="<?php echo base_url('assets/admin/vendors/bower_components/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.js'); ?>"></script>



	<!-- Bootstrap Switch JavaScript -->

		<script src="<?php echo base_url('assets/admin/vendors/bower_components/bootstrap-switch/dist/js/bootstrap-switch.min.js'); ?>"></script>



	<!-- Fancy Dropdown JS -->

	<script src="<?php echo base_url('assets/admin/dist/js/dropdown-bootstrap-extended.js'); ?>"></script>

	

	<!-- Sparkline JavaScript -->

	<script src="<?php echo base_url('assets/admin/vendors/jquery.sparkline/dist/jquery.sparkline.min.js'); ?>"></script>

	

	<!-- Switchery JavaScript -->

	<script src="<?php echo base_url('assets/admin/vendors/bower_components/switchery/dist/switchery.min.js'); ?>"></script>

	

	<!-- Toast JavaScript -->

	<script src="<?php echo base_url('assets/admin/vendors/bower_components/jquery-toast-plugin/dist/jquery.toast.min.js'); ?>"></script>

	

	<!-- Init JavaScript -->

	<script src="<?php echo base_url('assets/admin/dist/js/init.js'); ?>"></script>

	<script src="<?php echo base_url('assets/admin/dist/js/dashboard-data.js'); ?>"></script>

	<script type="text/javascript">

		$('#datable_1').DataTable();
		$('#datable_2').DataTable();
		$('#datable_3').DataTable({
			pageLength:25
		});

	</script>



	<script type="text/javascript">

      $(".js-example-tags").select2({

        tags: true

      });

      $(".select2").select2();

    </script>



     <script src="<?php echo base_url('assets/formvalidation/js/formValidation.min.js'); ?>"></script>



      <script src="<?php echo base_url('assets/formvalidation/js/framework/bootstrap.min.js'); ?>"></script>



      <script src="<?php echo base_url('assets/admin/js/form-validation.js'); ?>"></script>
      <script type="text/javascript">
        $(function () {
            $('.datetimepicker').datetimepicker({
                format: "YYYY-MM-DD HH:mm:ss",
            });
            $('.start_dt').datetimepicker({
                format: "YYYY-MM-DD",
            });
            $('.end_dt').datetimepicker({
                format: "YYYY-MM-DD",
            });
            $('.productExpireDate').datetimepicker({
                format: "YYYY-MM-DD",
            });
            $('#datetimepicker2').datetimepicker({
				//format: 'YYYY-MM-DD hh:ii',
				defaultDate:new Date()
			}).on('dp.change', function(e){
			  if( !e.oldDate || !e.date.isSame(e.oldDate, 'day')){
			    $(this).data('DateTimePicker').hide();
			  }
			});
        });
      </script>

</body>



</html>