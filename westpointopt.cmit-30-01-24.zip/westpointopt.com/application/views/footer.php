<!-- footer start -->
<footer>
    <div class="footer-top">
        <div class="container">
            <div class="row">
                <div class="col-lg-1 col-md-2 col-sm-12 col-12">
                    <div class="footer-content mb-4 mb-md-0">
                        <div class="footer-title">
                            <img src="<?php echo base_url(); ?>assets/user/img/logo.webp" alt="location icon" width="100">
                        </div>
                    </div>
                </div>
                <div class="col-lg-11 col-md-10 col-sm-12 col-12 pt-3 ps-lg-4">
                    <div class="row">
                        <div class="col-lg-5 col-sm-12 col-12">
                            <div class="footer-content mb-4 mb-md-0">
                                <div class="footer-title">
                                    <h4>West Point Optometrist LLP</h4>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-7 col-sm-12 col-12">
                            <div class="footer-content links mb-4 mb-md-0">
                                <ul class="list-unstyled quick-links mb-0">
                                    <li><a href="<?php echo base_url() ?>">Home</a></li>
                                    <li><a href="<?php echo base_url() ?>about-us">About </a></li>
                                    <li><a href="<?php echo base_url() ?>contact-us">Contact Us</a></li>
                                    <li><a href="<?php echo base_url() ?>products">Shop</a></li>
                                    <li><a href="<?php echo base_url() ?>privacy-policy"> Privacy Policy</a></li>
                                    <li><a href="<?php echo base_url() ?>terms-and-conditions"> Terms & Conditions</a></li>
                                    <li><a href="#">  <img src="<?php echo base_url() ?>assets/user/img/facebook.webp" alt="facebook" width="24"> </a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="copyright d-lg-flex justify-content-between text-center pt-2">
                                <p class="mb-md-0 mb-1">Copyright by West Point Optometrist Pte Ltd @ 2023. All rights reserved</p>
                                <p class="mb-md-0 mb-0"> <a href="https://websentials.com.sg/" target="_blank"> Web Design By Websentials <img src="<?php echo base_url(); ?>assets/user/img/websentials.png" alt="websentials icon" width="20" class="ms-1"></a></p>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</footer>
<!-- footer end -->
<div class="whatsapp-img">
    <a href="https://wa.me/6594570380" target="_blank">
        <i class="fa fa-whatsapp"></i>
    </a>
</div>

<script>
    $('.closeATcModal').on('click', function () {
        $('.atc-success').hide().fadeOut();
        $('.atc-success1').hide().fadeOut();
    });
</script>
<script src="<?php echo base_url(); ?>assets/user/js/owl.carousel.min.js"></script>
<script src="<?php echo base_url(); ?>assets/user/js/main.js"></script>
<script src="<?php echo base_url(); ?>assets/ecommerce/js/custom.js"></script>
<script src="https://www.google.com/recaptcha/api.js"></script>
<script>
    $(window).scroll(function() {
        var sticky = $('.sticky'),
            scroll = $(window).scrollTop();

        if (scroll >= 100) sticky.addClass('fixed');
        else sticky.removeClass('fixed');
    });
</script>
<script>
    // owl carousel
    ;
    (function($) {
        'use strict'
        $('.owl-carousel.client-logo').owlCarousel({
            loop: true,
            margin: 10,
            nav: true,
            dots: false,
            navText: ["<img src='<?php echo base_url(); ?>assets/user/img/left-icon.webp'>", "<img src='<?php echo base_url(); ?>assets/user/img/right-icon.webp'>"],
            responsive: {
                0: {
                    items: 2,
                },
                600: {
                    items: 3,
                },
                1000: {
                    items: 4,
                },
            },
        })
        $('.owl-carousel.shopping-item').owlCarousel({
            loop: false,
            margin: 30,
            nav: true,
            dots: false,
            navText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"],
            responsive: {
                0: {
                    items: 1,
                },
                500: {
                    items: 2,
                },
                700: {
                    items: 3,
                },
                1000: {
                    items: 3,
                },
            },
        })
        $('.owl-carousel.shopping-related').owlCarousel({
            loop: false,
            margin: 80,
            nav: false,
            dots: false,
            responsive: {
                0: {
                    items: 1,
                },
                500: {
                    items: 2,
                },
                700: {
                    items: 3,
                },
                1000: {
                    items: 4,
                },
            },
        })
    })(jQuery)
</script>
</body>

</html>