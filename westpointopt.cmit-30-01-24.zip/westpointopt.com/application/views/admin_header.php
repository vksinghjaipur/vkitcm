<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8" />

	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

	<title><?php echo $head_title; ?></title>

	<meta name="description" content="" />

	<meta name="keywords" content="" />

	<meta name="author" content=""/>
<!-- Data table CSS -->
 <link rel="shortcut icon" href="<?php echo base_url('assets/user/images/favicon.png'); ?>">
    <link rel="icon" href="<?php echo base_url('assets/user/images/favicon.png'); ?>" type="image/x-icon">

	<link href="<?php echo base_url('assets/admin/vendors/bower_components/datatables/media/css/jquery.dataTables.min.css'); ?>" rel="stylesheet" type="text/css"/>

	<link href="<?php echo base_url('assets/admin/vendors/bower_components/select2/dist/css/select2.min.css'); ?>" rel="stylesheet" type="text/css"/>

	<link href="<?php echo base_url('assets/admin/vendors/bower_components/multiselect/css/multi-select.css'); ?>" rel="stylesheet" type="text/css"/>

<link href="<?php echo base_url('assets/admin/vendors/bower_components/x-editable/dist/bootstrap3-editable/css/bootstrap-editable.css'); ?>" rel="stylesheet" />

	<link href="<?php echo base_url('assets/admin/vendors/bower_components/bootstrap-select/dist/css/bootstrap-select.min.css'); ?>" rel="stylesheet" type="text/css"/>

	<link href="<?php echo base_url('assets/admin/vendors/bower_components/mjolnic-bootstrap-colorpicker/dist/css/bootstrap-colorpicker.min.css'); ?>" rel="stylesheet" type="text/css"/>

	<link href="<?php echo base_url('assets/admin/vendors/bower_components/eonasdan-bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.min.css'); ?>" rel="stylesheet" type="text/css"/>

	<!-- Toast CSS -->

	<link href="<?php echo base_url('assets/admin/vendors/bower_components/jquery-toast-plugin/dist/jquery.toast.min.css'); ?>" rel="stylesheet" type="text/css">

		

	<!-- Custom CSS -->

	<link href="<?php echo base_url('assets/formvalidation/css/formValidation.css'); ?>" rel="stylesheet" type="text/css">

	

	<link href="<?php echo base_url('assets/admin/dist/css/style.css'); ?>" rel="stylesheet" type="text/css">

	

	<!-- jQuery -->

    <script src="<?php echo base_url('assets/admin/vendors/bower_components/jquery/dist/jquery.min.js'); ?>"></script>



    <!-- Bootstrap Core JavaScript -->

    <script src="<?php echo base_url('assets/admin/vendors/bower_components/bootstrap/dist/js/bootstrap.min.js'); ?>"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<style>

		.rating {
		    float:left;
		}

		/* :not(:checked) is a filter, so that browsers that don’t support :checked don’t 
		   follow these rules. Every browser that supports :checked also supports :not(), so
		   it doesn’t make the test unnecessarily selective */
		.rating:not(:checked) > input {
		    position:absolute;
		    top:-9999px;
		    clip:rect(0,0,0,0);
		}

		.rating:not(:checked) > label {
		    float:right;
		    width:1em;
		    padding:0 .1em;
		    overflow:hidden;
		    white-space:nowrap;
		    cursor:pointer;
		    font-size:200%;
		    line-height:1.2;
		    color:#ddd;
		    text-shadow:1px 1px #bbb, 2px 2px #666, .1em .1em .2em rgba(0,0,0,.5);
		}

		.rating:not(:checked) > label:before {
		    content: '★ ';
		}

		.rating > input:checked ~ label {
		    color: #f70;
		    text-shadow:1px 1px #c60, 2px 2px #940, .1em .1em .2em rgba(0,0,0,.5);
		}

		.rating:not(:checked) > label:hover,
		.rating:not(:checked) > label:hover ~ label {
		    color: gold;
		    text-shadow:1px 1px goldenrod, 2px 2px #B57340, .1em .1em .2em rgba(0,0,0,.5);
		}

		.rating > input:checked + label:hover,
		.rating > input:checked + label:hover ~ label,
		.rating > input:checked ~ label:hover,
		.rating > input:checked ~ label:hover ~ label,
		.rating > label:hover ~ input:checked ~ label {
		    color: #ea0;
		    text-shadow:1px 1px goldenrod, 2px 2px #B57340, .1em .1em .2em rgba(0,0,0,.5);
		}

		.rating > label:active {
		    position:relative;
		    top:2px;
		    left:2px;
		}
	
	</style>


</head>



<body>

	<!-- Preloader -->

	<div class="preloader-it">

		<div class="la-anim-1"></div>

	</div>

	<!-- /Preloader -->