<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php if(isset($seo['seo_title']) && $seo['seo_title']!=''){ ?>
<title><?php echo $seo['seo_title']; ?></title>
<?php }else{ ?>
<title>West Point Optometrist LLP</title>
<?php } ?>
<?php if(isset($seo['seo_keyword']) && $seo['seo_keyword']!=''){ ?>
<meta name="keyword" content="<?php echo $seo['seo_keyword']; ?>">
<?php }else{ ?>
<meta name="keyword" content="">
<?php } ?>
<?php if(isset($seo['seo_description']) && $seo['seo_description']!=''){ ?>
<meta name="description" content="<?php echo $seo['seo_description']; ?>">
<?php }else{ ?>
<meta name="description" content="">
<?php } ?>
<meta name="revisit-after" content="1 day">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="start-url" content="#">
<meta name="theme-color" content="#ffffff">
<meta name="copyright" content="Copyright by West Point Optometrist LLP">
<meta name="author" content="West Point Optometrist LLP">
<meta name="classification" content="West Point Optometrist LLP">
<meta name="robots" content="index, follow">
<meta name="distribution" content="india & all world">
<meta name="category" content="West Point Optometrist LLP">
<meta name="doc-type" content="public">
<meta name="rating" content="General">
<meta property="og:locale" content="en_US">
<meta property="og:type" content="website">
<meta property="og:title" content="West Point Optometrist LLP">
<meta property="og:url" content="#">
<meta property="og:site_name" content="West Point Optometrist LLP">
<meta property="og:image" content="<?php echo base_url(); ?>assets/user/img/favicon.webp">
<meta property="og:description" content="West Point Optometrist LLP">
<link rel="alternate" hreflang="en" href="<?php echo base_url($_SERVER['REQUEST_URI']); ?>">
<link rel="manifest" href="manifest.json">
<link rel="canonical" href="<?php echo base_url($_SERVER['REQUEST_URI']); ?>">
<link rel="icon" type="image/x-icon" href="<?php echo base_url(); ?>assets/user/img/favicon.webp" sizes="512x512">
<link rel="shortcut icon" href="<?php echo base_url(); ?>assets/user/img/favicon.webp" type="image/x-icon">
<link rel="apple-touch-icon" href="<?php echo base_url(); ?>assets/user/img/favicon.webp" sizes="180x180">

<link rel="stylesheet" href="<?php echo base_url(); ?>assets/user/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/user/scss/style.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/user/css/owl.carousel.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/user/css/owl.theme.default.min.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="<?php echo base_url(); ?>assets/user/js/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>assets/user/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo base_url(); ?>assets/formvalidation/js/formValidation.min.js"></script>
<script src="<?php echo base_url(); ?>assets/formvalidation/js/framework/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/user/js/custom-validation.js"></script>
<script>var path = "<?php echo base_url(); ?>";</script>
<style>
span.product-count {position: absolute;top: 10px;right: -12px;width: 15px;height: 15px;line-height: 15px;border-radius: 100%;font-size: 11px;font-weight: 500;display: inline-block;text-align: center;color: #ffffff;}
</style>
<!-- Google tag (gtag.js) --> <script async src="https://www.googletagmanager.com/gtag/js?id=G-79TSDE3YYY"></script> <script> window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'G-79TSDE3YYY'); </script>
</head>
<?php $page = uri_string(); ?>
<body>
    <!-- header start -->
    <header>
        <nav class="navbar navbar-expand-lg sticky">
            <div class="container">
                <a class="navbar-brand" href="<?php echo base_url(); ?>">
                    <img src="<?php echo base_url(); ?>assets/user/img/logo.webp" alt="logo image"> West Point Optometrist LLP
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span><i class="fa fa-bars"></i></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto align-items-center">
                        <li class="nav-item">
                            <a class="nav-link <?php echo($page=='' || $page=='index')?'active':''; ?>" href="<?php echo base_url(); ?>">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo($page=='about-us')?'active':''; ?>" href="<?php echo base_url(); ?>about-us">About Us</a>
                        </li>
                        <li class="nav-item has-dropdown">
                            <a class="nav-link <?php echo($page=='primary-eye-health-examination' || $page=='prescriptive-eyewear' || $page=='myopia-control-solutions' || $page=='contact-lens-fit')?'active':''; ?>" href="javascript:void()"> Services <i class="fa fa-angle-down"></i>
                            </a>
                            <ul class="drop-menu list-unstyled">
                                <li class="nav-item"><a class="nav-link" href="<?php echo base_url(); ?>primary-eye-health-examination">Primary Eye Health Examination</a></li>
                                <li class="nav-item"><a class="nav-link" href="<?php echo base_url(); ?>prescriptive-eyewear">Prescriptive Eyewear</a></li>
                                <li class="nav-item"><a class="nav-link" href="<?php echo base_url(); ?>myopia-control-solutions">Myopia Control Solutions</a></li>
                                <li class="nav-item"><a class="nav-link" href="<?php echo base_url(); ?>contact-lens-fit"> Contact Lens FIt </a></li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo($page=='articles')?'active':''; ?>" href="<?php echo base_url(); ?>articles">Articles</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo($page=='contact-us')?'active':''; ?>" href="<?php echo base_url(); ?>contact-us">Contact</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo($page=='products')?'active':''; ?>" href="<?php echo base_url(); ?>products">Shop</a>
                        </li>
                    </ul>
                    <ul class="right-nav d-flex list-unstyled">
                        
                        <li class="nav-item">
                            <?php $login = $this->session->userdata('is_user_logged_in'); 
                                 if($login==1){
                                    if($this->session->userdata("user_login_type")=="guest_user"){
                            ?>
                                <a href="<?php echo base_url("user-login"); ?>" class="nav-link">
                                    <img src="<?php echo base_url(); ?>assets/user/img/user-icon.webp" alt="user icon">
                                </a>
                            <?php }else{ ?>
                                <a href="<?php echo ($this->session->userdata("user_login_type")=="guest_user")?base_url():base_url("user-profile"); ?>" class="nav-link">
                                    <img src="<?php echo base_url(); ?>assets/user/img/user-icon.webp" alt="user icon">
                                </a>
                            <?php } }else{ ?>
                                <a href="<?php echo base_url("user-login"); ?>" class="nav-link">
                                    <img src="<?php echo base_url(); ?>assets/user/img/user-icon.webp" alt="user icon">
                                </a>
                            <?php } ?>
                        </li>
                        <li class="nav-item" style="position:relative;">
                            <a href="<?php echo base_url(); ?>shopping-cart" class="nav-link">
                                <img src="<?php echo base_url(); ?>assets/user/img/cart-icon.webp" alt="shop icon">
                                <span class="product-count bg-black" id="cart-total"><?php echo count($this->cart->contents()); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <!-- header end -->