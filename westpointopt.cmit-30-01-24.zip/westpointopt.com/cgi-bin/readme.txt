IT Works Interactive - Setup instructions.
--------------------------------------------------

Windows Form Mailer
Form Configuration 

The action of your form needs to point towards this script (obviously), and the method must be POST or GET in capital letters. Version 1.92 of FormMail offers many new ways to code your form to tailor the resulting HTML page and the way the script performs.

Below is a list of form fields you can use and how to implement them. Here's a sample HTML codes to create a form.
1) <form method=post action="/cgi-bin/fm.pl"> 
2) <input type="hidden" name="subject" value="Feedback Form">
3) <input type="hidden" name="recipient" value="your@emailaddress.com">
4) <input type="hidden" name="return_link_title" value="back to your website name.">
5) <input type="hidden" name="return_link_url"value="http://www.yourdomainname.com/form.htm">
6) <input type="hidden" name="required" value="Name,email">
7) <input type=hidden name="env_report" value="REMOTE_HOST,HTTP_USER_AGENT"> 
8) </form> 

Explaination of each line.

1) This calls the script.
2) Here we define the subject of the email that the form will send.
3) Here we define the email address the form will send to.
4) Here we set the return link title
5) Here we set the URL of the return link.
6) We can set certain fields to be required eg fields : Name & Email is required.
7) If you wish to include the visitors IP address then include this line.
8) End of Form.

Necessary Form Fields: 

There is only one form field that you must have in your form, for FormMail to work correctly. This is the recipient field. 

Field: recipient

Description: This form field allows you to specify to whom you wish for your form results to be mailed. Most likely you will want to configure this option as a hidden form field with a value equal to that of your e-mail address.

Syntax: <input type=hidden name="recipient" value="your@emailaddress.com"> 

You need to edit the following lines in fm.pl

@referers = ('www.yourdomainname.com','yourdomainname.com');
@recipients = ('your@emailaddress.com');

1) Edit www.yourdomain.name.com and yourdomainname.com to your domain name.
2) Edit your@emailaddress.com to your email address. (Same as the recipient value)


