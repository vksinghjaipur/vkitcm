<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the selected payment option
    $paymentOption = isset($_POST['payment_option']) ? $_POST['payment_option'] : '';

    // Perform different actions based on the selected option
    if ($paymentOption == 'cash') {
        // Redirect to the cash payment page
        header("Location: cash_payment_page.php");
        exit();
    } elseif ($paymentOption == 'online') {
        // Redirect to the online payment page
        header("Location: online_payment_page.php");
        exit();
    } else {
        echo "<p>Please select a payment option.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Form</title>
</head>
<body>

<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    <label>
        <input type="radio" name="payment_option" value="cash">Cash
    </label>
    <br>
    <label>
        <input type="radio" name="payment_option" value="online"> Online
    </label>
    <br>
    <input type="submit" value="Submit">
</form>

</body>
</html>
