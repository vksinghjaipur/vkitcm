<?php
include_once 'config.php';
include_once 'common.php';
?>

    <div class="apnaindia_nav"> 
        <div class="container">
        	<h1 class="text-success">Success</h1>

            <?php
               print_r($_GET);
            ?>  

        	<p>Transaction ID : <?php echo $_GET['tid'];?> </p>

            <p>Amount : <?php echo $_GET['amount'];?></p>
        	

            <p class="text-primary">Thank you for payment</p>
        </div>
    </div>

