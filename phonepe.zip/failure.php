<?php
include_once 'config.php';
include_once 'common.php';
?>

    <div class="apnaindia_nav"> 
        <div class="container">
        	<h1 class="text-danger">Failed</h1>
        	
            <?php
               print_r($_GET);
            ?>   

            
        </div>
    </div>

