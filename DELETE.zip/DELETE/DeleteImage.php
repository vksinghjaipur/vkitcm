<?php


public function productsDelete($id=null)
    {
        Product::where('id',$id)->delete();
        return new RedirectResponse(route('admin.products.show'), ['flash_success' => __('The Product was successfully deleted.')]);
    }

    public function deleteImage($id=null)
    {
        $productImage = ProductsImage::where('id',$id)->first();
        
        $image_path= 'img/products_image/';
        if(file_exists($image_path.$productImage->image))
        {
            unlink($image_path.$productImage->image);
        }
        ProductsImage::where('id',$id)->delete();
        return redirect()->back();
    }