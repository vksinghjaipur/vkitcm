@extends('backend.layouts.app')
@section('title', app_name() . ' | ' . __('Service Management'))
@section('breadcrumbs')
<x-backend-breadcrumbs>
    <x-backend-breadcrumb-item type="active"><i class="fa fa-wrench"></i> Services</x-backend-breadcrumb-item>
</x-backend-breadcrumbs>
@endsection
@section('content')
<!-- <div class="content-header">
    <div id="message_success" style="display:none" class="alert alert-success"> Status Enabled </div>
    <div id="message_error" style="display:none" class="alert alert-danger"> Status Disabled </div>
</div> -->
<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-sm-7">
                <h4 class="card-title mb-0">
                    {{ __('Services') }} 
                </h4>
            </div>
           <div class="col-5">
                <div class="float-right">
                    <x-buttons.create route='{{ route("backend.services.create") }}' title="{{__('Create')}}" />

                    <div class="btn-group" role="group" aria-label="Toolbar button groups">
                        <div class="btn-group" role="group">
                            <button id="btnGroupToolbar" type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-cog"></i>
                            </button>
                            <div class="dropdown-menu" aria-labelledby="btnGroupToolbar">
                                <a class="dropdown-item" href="">
                                    <i class="fas fa-eye-slash"></i> View trash
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--row-->

        <div class="row mt-4">
            <div class="col">
                <div class="table-responsive">
                    <table id="example1" class="table table-striped table-bordered" style="width:100%">
                         <thead>
                            <tr>
                                <th>Id</th>
                                <th>Service Name</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if(isset($services) && !empty($services))
                            @foreach($services as $busin)
                            <tr>
                                <td>{{$loop->iteration}}</td>
                                <td>{{ucwords($busin->service_name)}}</td>                               
                              
                                <td>
                                    <input class="changeUserStatus btn btn-success chkToggle2" type="checkbox" rel="{{$busin->id}}" data-toggel="toggel" data-on="on" data-of="no" data-onstyle="success" data-offstyle="danger" data-size="xs" {{($busin->status) ? 'checked' : ''}}>
                                </td>

                                <td class="btn-td">
                                    <div class="btn-group action-btn"><a href="{{url('admin/services/'.$busin->id.'/edit')}}" data-toggle="tooltip" data-placement="top" title="Edit" class="btn btn-primary btn-sm">
                                    <i class="fas fa-edit"></i>
                                    </a>

                                    <form method="POST" action="{{route('backend.services.delete',$busin->id)}}">
                                        @csrf
                                        <button type="button" class="btn btn-danger btn-sm show_confirm" data-toggle="tooltip" title='Delete Services'> <i class="fa fa-trash"></i></button>
                                    </form>
                                    </div>
                                </td>
                            </tr>
                            @endforeach
                            @endif
                        </tbody>    
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script type="text/javascript">
 
     $('.show_confirm').click(function(event) {
          var form =  $(this).closest("form");
          var name = $(this).data("name");
          event.preventDefault();
          swal({
              title: `Are you sure you want to Delete Services..?`,
              text: "Data will lost after delete.",
              icon: "success",
              buttons: true,
              dangerMode: true,
          })
          .then((willDelete) => {
            if (willDelete) {
              form.submit();
            }
          });
      });
    $('.nav-link').click(function()
    {
      var type= $(this).data('approve');
      $('.searchtype').val(type);
    })
</script>


<script>
    $(document).ready( function () {
        // for Update status //
        $(".changeUserStatus").change(function(){
            var id = $(this).attr('rel');
            if($(this).prop("checked")==true){
            $.ajax({ 
                headers: {
                   'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type : 'post',
                url : '{{route('backend.services.update-status')}}',
                data : {status:'1',id:id},
                success:function(data){
                   toastr.success(data.success);
                },error:function(){
                   alert("Error");
                }
            });
            }else{
            $.ajax({
                headers: {
                   'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                    type : 'post',
                    url : '{{route('backend.services.update-status')}}',
                    data : {status:'0',id:id},
                    success:function(data){
                    if(data.status==0)
                    {
                           toastr.error(data.error);
                    }
                    else{
                        toastr.success(data.success);
                    }
                    },error:function(){
                       alert("Error");
                    }
                });
            }
        });  
});
</script>

@endsection
@section('pagescript')
<script>
    $(document).ready(function() {
    $('#example').DataTable();
} );
</script>

@stop
