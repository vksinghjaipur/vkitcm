<div class="card-body">
    <div class="row">
        <div class="col-sm-5">
            <h4 class="card-title mb-0">
                {{ __('Service Management') }}
                <small class="text-muted">{{ (isset($getpack)) ? __('Edit Service') : __('Service create') }}</small>
            </h4>
        </div>
        <!--col-->
    </div>
    <!--row-->

    <hr>

    <div class="row mt-4 mb-4">
        <div class="col">
            <div class="form-group row">
                {{ Form::label('service_name', trans('Service Name'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                    {{ Form::text('service_name', $services->service_name, ['class' => 'form-control', 'placeholder' => trans('Service name'), 'required' => 'required']) }}
                </div>
                <!--col-->
            </div>
            <!--form-group-->
  
        </div>
    </div>
</div>
<script src="https://cdn.ckeditor.com/4.16.2/standard-all/ckeditor.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
