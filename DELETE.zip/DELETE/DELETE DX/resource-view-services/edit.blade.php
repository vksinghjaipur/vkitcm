@extends('backend.layouts.app')

@section('title', __('Services Management') . ' | ' . __('labels.backend.access.service.edit'))

@section('breadcrumbs')
<x-backend-breadcrumbs>
    <x-backend-breadcrumb-item route='{{route("backend.services")}}' icon=''><i class="fa fa-wrench"></i>
        Services
        
    </x-backend-breadcrumb-item>

    <x-backend-breadcrumb-item type="active">{{ __() }}</x-backend-breadcrumb-item>
</x-backend-breadcrumbs>
@endsection

@section('content')
<form method="post" action="{{route('backend.services.update',$services->id)}}" enctype="multipart/form-data">
  @csrf
    <div class="card">
        @include('backend.services.editform')
        <div class="row">
            <div class="col-sm-4">
                <div class="form-group ml-3">
                    {{ html()->submit($text = icon('fas fa-save')." Save")->class('btn btn-success') }}
                </div>
            </div>

            <div class="col-sm-8">
                <div class="float-right mr-3">
                    <a href="{{ route("backend.services") }}" class="btn btn-warning" data-toggle="tooltip" title="{{__('labels.backend.cancel')}}"><i class="fas fa-reply"></i> Cancel</a>
                </div>
            </div>
        </div>
    </div><!--card-->
</form>
@endsection