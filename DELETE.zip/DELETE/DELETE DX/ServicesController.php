<?php
namespace App\Http\Controllers\Backend;
use App\Http\Controllers\Controller;
use App\Http\Responses\RedirectResponse;
use Illuminate\Http\Request;
use App\Models\Setting;
use App\Models\Service;
use Auth, DB;
use Illuminate\Support\Str;
use Log;

class ServicesController extends Controller
{
    public function index(Request $request)
    {
        $services = DB::table('services')
        ->orderBy('service_name', 'ASC')
        ->get();
        return view('backend.services.index', compact('services'));
    }

    public function create()
    {
        return View('backend.services.create');
    }

    public function store(Request $request)
    {  
       //echo '<pre>'; print_r($request->all());exit;
        $service_name = $request->service_name;
        $status = $request->status;
        $values = array('service_name' => $service_name, 'status' => $status);
        
        DB::table('services')->insert($values);
       
       return new RedirectResponse(route('backend.services'), ['message' => __('The Service successfully created.')]);
    }

    public function edit($id=null)
    {
        $services= DB::table('services')->where('id',$id)->first();
        return view('backend.services.edit', compact('services'));
    }

    public function update(Request $request ,$id=null)
    {
        // echo '<pre>'; print_r($request->all());exit;
        $servicetype= array();
        $servicetype['service_name']=$request->service_name;
       
       
        DB::table('services')->where('id',$id)->update($servicetype);

        return new RedirectResponse(route('backend.services'), ['message' => __('The Service successfully updated.')]);
    }

    public function servicesDelete($id=null)
    {
        DB::table('services')->where('id',$id)->delete();
        return new RedirectResponse(route('backend.services'), ['message' => __('The Services successfully deleted.')]);
    }

    public function updateStatus(Request $request,$id=null)
    {
        $data = $request->all();
        Service::where('id',$data['id'])->update(['status'=>$data['status']]);
        if($data['status']==0)
        {
            return response()->json(['error' => 'Service off updated successfully','status'=>0]);
        }
            return response()->json(['success' => 'Service on successfully updated','status'=>1]);
    }

}
