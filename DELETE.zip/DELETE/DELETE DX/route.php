<?php


 /* Service Name Route */
    Route::get('services', 'ServicesController@index')->name('services');
    Route::get('services/create', 'ServicesController@create')->name('services.create');
    Route::post('services/store', 'ServicesController@Store')->name('services.store');
    Route::get('services/{id}/edit', 'ServicesController@edit')->name('services.edit');
    Route::post('services/update/{id}', 'ServicesController@Update')->name('services.update');
    

    Route::post('services/delete/{id}', 'ServicesController@servicesDelete')->name('services.delete');
   

    Route::post('services/update-status','ServicesController@updateStatus')->name('services.update-status');
    Route::post('services/is_featured','ServicesController@ServiceFeatured')->name('services.is_featured');