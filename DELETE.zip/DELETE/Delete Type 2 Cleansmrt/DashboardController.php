<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller;


use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\User;
use App\Models\UserMeta;
use DB;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //$this->middleware('auth.admin');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {  
        $users=db::table('users')
        ->where('users.user_role_id', 2)
        ->where('users.deleted_at', null)
        ->get();
        return view('dashboard.index',compact('users'));       
    }


    public function logout()
    {
        Auth::logout();
        //return view('login');
        return redirect()->route('login');
    }

    public function changeUserStatus(Request $request)
    {
        $user = User::find($request->user_id);
        $user->status = $request->status;
        $user->save();
  
        return response()->json(['success'=>'User status change successfully.']);
    }



    // public function updateStatus(Request $request,$id=null)
    // {
    //   $data = $request->all();
    //   User::where('id',$data['id'])->update(['status'=>$data['status']]);
    // }

    public function favourite($id)
    {
        $details=User::where('id',$id)->first();
        if($details->is_favourite==1)
        {
            $data['is_favourite']="0";
            $msg="Unfavourite successfully";
        }
        else
        {
            $data['is_favourite']="1";
            $msg="Favourite Added Successfully";
        }
        User::where('id',$id)->update($data);
        return back()->with('success', $msg);
    }


    public function delete($id)
    {
        User::find($id)->delete();
        UserMeta::find($id,user_id)->delete();
  
        return back();
    }


    // public function delete()
    // {
    //     User::truncate();
  
    //     return 'ok';
    // }
    
}
