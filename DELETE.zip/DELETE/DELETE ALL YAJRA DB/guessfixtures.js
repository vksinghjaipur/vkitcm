(function () {

    FTX.Guessfixtures = {

        list: {

            selectors: {
                guessfixtures_table: $('#guessfixtures-table'),
            },

            init: function () {

                this.selectors.guessfixtures_table.dataTable({

                    processing: false,
                    serverSide: true,
                    ajax: {
                        url: this.selectors.guessfixtures_table.data('ajax_url'),
                        type: 'post',
                    },
                    columns: [

                        { data: 'checkbox', name: 'checkbox',  orderable:false, searchable:false },
                        { data: 'id', name: 'id' },
                        { data: 'league_id', name: 'league_id' },
                        { data: 'league_name', name: 'league_name' },
                        { data: 'team_home_name', name: 'team_home_name' },
                        { data: 'team_home_logo', name: 'guessfixtures.team_home_logo',
                    render: function( data, type, full, meta ) {
                        return "<img src=\"" + data + "\" height=\"50\"/>";
                        //return "<img src=\"/storage/img/fixture/" + data + "\" height=\"50\"/>";
                        }},
                        { data: 'team_away_name', name: 'team_away_name' },
                        { data: 'team_away_logo', name: 'guessfixtures.team_away_logo',
                    render: function( data, type, full, meta ) {
                        return "<img src=\"" + data + "\" height=\"50\"/>";
                        }},
                        { data: 'publish_datetime', name: 'guessfixtures.publish_datetime' },
                        // { data: 'guess_close_time', name: 'fixtures.guess_close_time' },
                        
                        { data: 'date', name: 'guessfixtures.date'},
                        { data: 'status', name: 'status' },
                        // { data: 'created_by', name: 'created_by' },
                        // { data: 'created_at', name: 'created_at' },
                        
                        { data: 'actions', name: 'actions', searchable: false, sortable: false }

                    ],
                    order: [[3, "asc"]],
                    searchDelay: 500,
                    "createdRow": function (row, data, dataIndex) {
                        FTX.Utils.dtAnchorToForm(row);
                    }
                });
            }
        },

       

    }

    
})();