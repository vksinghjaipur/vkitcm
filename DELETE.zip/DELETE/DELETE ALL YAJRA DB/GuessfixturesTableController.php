<?php

namespace App\Http\Controllers\Backend\Guessfixtures;

use App\Http\Controllers\Controller;
use App\Http\Requests\Backend\Guessfixtures\ManageGuessfixturesRequest;
use App\Repositories\Backend\GuessfixturesRepository;
use Yajra\DataTables\Facades\DataTables;

/**
 * Class GuessfixturesTableController.
 */
class GuessfixturesTableController extends Controller
{
    /**
     * @var \App\Repositories\Backend\GuessfixturesRepository
     */
    protected $repository;

    /**
     * @param \App\Repositories\Backend\Guessfixtures\GuessfixturesRepository $repository
     */
    public function __construct(GuessfixturesRepository $repository)
    {
        $this->repository = $repository;
    }

    /**
     * @param \App\Http\Requests\Backend\Guessfixtures\ManageGuessfixturesRequest $request
     *
     * @return mixed
     */
    public function __invoke(ManageGuessfixturesRequest $request)
    {
        return Datatables::of($this->repository->getForDataTable())
            // ->filterColumn('status', function ($query, $keyword) {
            //     if (in_array(strtolower($keyword), ['active', 'inactive'])) {
            //         $query->where('guessfixture.status', (strtolower($keyword) == 'active') ? 1 : 'inactive');
            //     }
            // })
          

            ->filterColumn('created_by', function ($query, $keyword) {
                $query->whereRaw('users.first_name like ?', ["%{$keyword}%"]);
            })

            
            ->editColumn('status', function ($guessfixture) {
                return $guessfixture->status_label;
            })
            //  ->addColumn('publish_datetime', function ($guessfixture) {
            //     return $guessfixture->publish_datetime->format('d/m/Y h:i A');
            // })
            ->editColumn('created_at', function ($guessfixture) {
                return $guessfixture->created_at->toDateString();
            })

            ->addColumn('checkbox', function ($guessfixture) {
                return '<input type="checkbox" name="league_name" data-id="'.$guessfixture['id'].'"><label></label>';
            })

            ->addColumn('actions', function ($guessfixture) {
                return $guessfixture->action_buttons;
            })

            ->rawColumns(['actions','checkbox'])
            ->escapeColumns(['name'])
            ->make(true);

           
    }
}
