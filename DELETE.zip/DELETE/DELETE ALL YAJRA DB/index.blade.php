@extends('backend.layouts.app')

@section('title', app_name() . ' | ' . __('labels.backend.access.guessfixtures.management'))

@section('breadcrumb-links')
@include('backend.guessfixtures.includes.breadcrumb-links')
@endsection

<link rel="stylesheet" href="{{ asset('datatable/css/dataTables.bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('datatable/css/dataTables.bootstrap4.min.css') }}">
    <link rel="stylesheet" href="{{ asset('sweetalert2/sweetalert2.min.css') }}">
    <link rel="stylesheet" href="{{ asset('toastr/toastr.min.css') }}">
@section('content')
<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-sm-5">
                <h4 class="card-title mb-0">
                    {{ __('labels.backend.access.guessfixtures.management') }} <small class="text-muted">{{ __('labels.backend.access.guessfixtures.active') }}</small>
                </h4>
            </div>
            <!--col-->
        </div>
        <!--row-->
        <center><h4><u>Fixtures For Guess Matches</u></h4></center>
         <center><strong>Status->  <span class="text-success">Active = Guess On,</span> <span class="text-danger">Inactive = Guess Off</span></center></strong><br>
          <center><a class="btn btn-info" href="http://localhost/guesszone/public/import/fixtures" target="_blank">Click for Update Matches From API</a></center>

        <div class="row mt-4">
            <div class="col">
                {{-- <div class="table-responsive"> --}}
                    <table id="guessfixtures-table" class="table table-bordered" data-ajax_url="{{ route("admin.guessfixtures.get") }}">
                        <thead>
                            <tr>

                                <!-- <th>{{ trans('labels.backend.access.guessfixtures.table.checkbox') }}</th> -->
                                <th><input type="checkbox" name="main_checkbox"><label></label></th>
                                <th>{{ trans('labels.backend.access.guessfixtures.table.id') }}</th>
                                <th>{{ trans('labels.backend.access.guessfixtures.table.league_id') }}</th>
                                <th>{{ trans('labels.backend.access.guessfixtures.table.league_name') }}</th>
                                
                                <th>{{ trans('labels.backend.access.guessfixtures.table.team_home_name') }}</th>
                                <th>{{ trans('labels.backend.access.guessfixtures.table.team_home_logo') }}</th>
                                <th>{{ trans('labels.backend.access.guessfixtures.table.team_away_name') }}</th>
                                <th>{{ trans('labels.backend.access.guessfixtures.table.team_away_logo') }}</th>
                                <th align="center">{{ trans('labels.backend.access.guessfixtures.table.publish_datetime') }}</th>
                                <th>{{ trans('labels.backend.access.guessfixtures.table.date') }}</th>                               
								<th>{{ trans('labels.backend.access.guessfixtures.table.status') }}</th>

                                {{-- <th>{{ trans('labels.backend.access.fixtures.table.createdby') }}</th>
                                <th>{{ trans('labels.backend.access.fixtures.table.createdat') }}</th> --}}
                                                               
                                <th>{{ trans('labels.general.actions') }} <button class="btn btn-sm btn-danger d-none" id="deleteAllBtn">Delete All</button></th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
            <!--col-->
        </div>
        <!--row-->

    </div>
    <!--card-body-->
</div>
<!--card-->

<script type="text/javascript">
$(document).on('click','input[name="main_checkbox"]', function(){
                  if(this.checked){
                    $('input[name="league_name"]').each(function(){
                        this.checked = true;
                    });
                  }else{
                     $('input[name="league_name"]').each(function(){
                         this.checked = false;
                     });
                  }
                  toggledeleteAllBtn();
           });
</script>

<script type="text/javascript">

           $(document).on('change','input[name="league_name"]', function(){

               if( $('input[name="league_name"]').length == $('input[name="league_name"]:checked').length ){
                   $('input[name="main_checkbox"]').prop('checked', true);
               }else{
                   $('input[name="main_checkbox"]').prop('checked', false);
               }
               toggledeleteAllBtn();
           });

</script>

<script type="text/javascript">
    function toggledeleteAllBtn(){
       if( $('input[name="league_name"]:checked').length > 0 ){
           $('button#deleteAllBtn').text('Delete ('+$('input[name="league_name"]:checked').length+')').removeClass('d-none');
       }else{
           //$('button#deleteAllBtn');
           $('button#deleteAllBtn').addClass('d-none');
       }
    }
</script>

<script type="text/javascript">
     $(document).on('click','button#deleteAllBtn', function(){
               var checkedCountries = [];
               $('input[name="league_name"]:checked').each(function(){
                   checkedCountries.push($(this).data('id'));
               });

               var url = '{{ route("delete.selected.countries") }}';
               if(checkedCountries.length > 0){
                   swal.fire({
                       title:'Are you sure?',
                       html:'You want to delete <b>('+checkedCountries.length+')</b> league name',
                       showCancelButton:true,
                       showCloseButton:true,
                       confirmButtonText:'Yes, Delete',
                       cancelButtonText:'Cancel',
                       confirmButtonColor:'#556ee6',
                       cancelButtonColor:'#d33',
                       width:300,
                       allowOutsideClick:false
                   }).then(function(result){
                       if(result.value){
                           $.post(url,{countries_ids:checkedCountries},function(data){
                              if(data.code == 1){
                                  $('#guessfixtures-table').DataTable().ajax.reload(null, true);
                                  toastr.success(data.msg);
                              }
                           },'json');
                       }
                   })
               }
           });
</script>  
@endsection

@section('pagescript')
<script>
    FTX.Utils.documentReady(function() {
        FTX.Guessfixtures.list.init();
    });
</script>

  
@stop