<?php

namespace App\Http\Controllers\Backend\Products;

use App\Http\Controllers\Controller;
use App\Http\Responses\RedirectResponse;
use Illuminate\Http\Request;
use App\Models\Scooter\Scooter;
use App\Models\Scooter\Package;
use App\Models\Scooter\Plan;
use App\Models\Scooter\DropPoint;
use App\Models\BlogCategory;
use App\Models\BlogTag;
use App\Models\Product;
use App\Models\ProductsImage;
use App\Models\Businessservice;
use App\Models\Businesstype;
use DB;
use Illuminate\Support\Facades\View;

class ProductsController extends Controller
{

    public function index(Request $request)
    { 
        //$products = DB::table('Products')
        $products=Product::
            join('product_image','product_image.p_id','=','products.id')
            ->groupBy('product_image.p_id')
            ->select('products.*', 'product_image.p_id','product_image.image')
            ->get();

         //echo '<pre>';print_r($products);die();   
        return view('backend.products.index', compact('products'));
    }

    /**
     * @param \App\Http\Requests\Backend\Blogs\ManageBlogsRequest $request
     *
     * @return ViewResponse
     */
    public function create()
    {
        return View('backend.products.create');
    }

    /**
     * @param \App\Http\Requests\Backend\Blogs\StoreBlogsRequest $request
     *
     * @return \App\Http\Responses\RedirectResponse
     */
    

    public function store(Request $request)
    {   
        $user_id =auth()->user()->id;
        $name = $request->name;
        $description = $request->description;
        $shipping_location = $request->shipping_location;
        $price = $request->price;
        $category_id = $request->category_id;
        $sub_cat_id = isset($request->sub_cat_id)?$request->sub_cat_id:0;
        $status = $request->status;
        $values = array('user_id' => $user_id,'name' => $name, 'description' => $description, 'shipping_location' => $shipping_location, 'price' => $price, 'category_id' => $category_id, 'sub_cat_id' => $sub_cat_id, 'status' => $status, 'user_id' => auth()->user()->id);
        $lastId=DB::table('products')->insertGetId($values);
        
            if($request->hasFile('image'))
            {     
                foreach($request->file('image') as $file)
                {
                    $name = time().'.'.$file->extension();
                    $image = rand(111,999).'.'.$file->extension();
                    $file->move(public_path().'/img/products_image/', $image);  
                    $file1 = array('p_id' => $lastId, 'image' => $image,);
                    DB::table('product_image')->insert($file1);
                }
            }
        return new RedirectResponse(route('admin.products.show'), ['flash_success' => __('The Products was successfully created.')]);
    }

    /**
     * @param \App\Models\Blog $blog
     * @param \App\Http\Requests\Backend\Blogs\ManageBlogsRequest $request
     *
     * @return \App\Http\Responses\Backend\Blog\EditResponse
     */
    public function edit($id=null)
    {
        $products= Product::with('images')->where('products.id',$id)
        ->first();
        $category = DB::table('business_types')->where('status',1)->get();
        $subcategory = DB::table('business_services')->where('status',1)->where('id',$products->sub_cat_id)->first();
        return view('backend.products.edit', compact('products','category','subcategory'));
    }

    /**
     * @param \App\Models\Blogs\Blog $blog
     * @param \App\Http\Requests\Backend\Blogs\UpdateBlogsRequest $request
     *
     * @return \App\Http\Responses\RedirectResponse
     */
    public function update(Request $request ,$id=null)
    {
        $products= array();      
        $products['name']=$request->name;
        $products['description']=$request->description;
        $products['shipping_location']=$request->shipping_location;
        $products['price']=$request->price;
        $products['category_id']=$request->category_id;
        $products['sub_cat_id']= isset($request->sub_cat_id)?$request->sub_cat_id:0;
        $products['status']=$request->status;

        if($request->hasFile('image'))
        {     
            foreach($request->file('image') as $file)
            {
                $name = time().'.'.$file->extension();
                $image = rand(111,999).'.'.$file->extension();
                $file->move(public_path().'/img/products_image/', $image);  
                $file1 = array('p_id' => $id, 'image' => $image,);
                DB::table('product_image')->insert($file1);
            }
        }
        
        Product::where('id',$id)->update($products);
        return new RedirectResponse(route('admin.products.show'), ['flash_success' => __('The Product was successfully updated.')]);
    }

    /**
     * @param \App\Models\Blog $blog
     * @param \App\Http\Requests\Backend\Blogs\ManageBlogsRequest $request
     *
     * @return \App\Http\Responses\RedirectResponse
     */
    public function productsDelete($id=null)
    {
        Product::where('id',$id)->delete();
        return new RedirectResponse(route('admin.products.show'), ['flash_success' => __('The Product was successfully deleted.')]);
    }

    public function deleteImage($id=null)
    {
        $productImage = ProductsImage::where('id',$id)->first();
        
        $image_path= 'img/products_image/';
        if(file_exists($image_path.$productImage->image))
        {
            unlink($image_path.$productImage->image);
        }
        ProductsImage::where('id',$id)->delete();
        return redirect()->back();
    }


    public function getCategory(Request $request)
    {
        $data['countries'] = Businessservice::where("business_id",$request->business_name)->get(["service_name","id"]);
        return response()->json($data);  
    }   

}
