<div class="card-body">
    <div class="row">
        <div class="col-sm-5">
            <h4 class="card-title mb-0">
                {{ __('Products Management') }}
                <small class="text-muted">{{ (isset($getpack)) ? __('Edit Plan') : __('Products create') }}</small>
            </h4>
        </div>
        <!--col-->
    </div>
    <!--row-->

    <hr>

    <div class="row mt-4 mb-4">
        <div class="col">
            <!--form-group Name Start-------->
            <div class="form-group row">
                {{ Form::label('name', trans('Name'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                    {{ Form::text('name', $products->name, ['class' => 'form-control', 'placeholder' => trans('Name '), 'required' => 'required']) }}
                </div>
            </div>
            <!--form-group Name end----------->

            <!--form-group Category Start-------->
            <div class="form-group row">
                {{ Form::label('category_id', trans('Category'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                    <select name="category_id" class="form-control" id="country-dropdown" required>
                        <option value="">Select Category Name</option>
                        @foreach ($category as $mycategory) 
                        <option class="text-info font-weight-bold" value="{{$mycategory->id}}" @if($products->category_id==$mycategory->id) selected @endif>
                        {{$mycategory->business_name}}
                        </option>
                        @endforeach
                    </select>
                </div>
                <!--col-->
            </div>
            <!--form-group Category end-------------->

            <!--form-group Sub Category Start-------->
            <div class="form-group row">
                {{ Form::label('sub_cat_id', trans('Sub Category'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                    <select class="form-control getleagename" id="state-dropdown" name="sub_cat_id">
                        <option value="{{isset($subcategory->id)?$subcategory->id:''}}">{{isset($subcategory->service_name)?$subcategory->service_name:''}}</option>
                    </select>
                </div>
                <!--col-->
            </div>
            <!--form-group Sub Category end---------->


            <!--form-group Description Start--------->
            <div class="form-group row">
                {{ Form::label('description', trans('Description'), ['class' => 'col-md-2 from-control-label required']) }}
                <div class="col-md-8">
                    {{ Form::textarea('description', $products->description, ['class' => 'form-control tinymce', 'placeholder' => trans('Description '), 'required' => 'required']) }}
                </div>
                <!--col-->
            </div>
            <!--form-group Description End----------->


            <!--form-group shipping_location Start-->
            <!-- <div class="form-group row">
                {{ Form::label('shipping_location', trans('Shipping Location'), ['class' => 'col-md-2 from-control-label required']) }}
                <div class="col-md-8">
                    {{ Form::textarea('shipping_location', $products->shipping_location, ['class' => 'form-control tinymce', 'placeholder' => trans('Shipping Location '), 'required' => 'required']) }}
                </div>
            </div> -->
            <!--form-group shipping_location End-->

            <!--form-group Price Start-->
            <div class="form-group row">
                {{ Form::label('price', trans('Price'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                    {{ Form::text('price', $products->price, ['class' => 'form-control', 'placeholder' => trans('Price '), 'required' => 'required']) }}
                </div>
                <!--col-->
            </div>
            <!--form-group Price End-->

            <!--form-group Prize Image Start-->
            <div class="form-group row">
                {{ Form::label('image', trans('Products'), ['class' => 'col-md-2 from-control-label required']) }}
                <div class="col-lg-5">
                    <input type="file" name="image[]" multiple="">
                </div>  
            </div>

            <div class="form-group row">
                {{ Form::label('image', trans(''), ['class' => 'col-md-2 from-control-label required']) }}
              @if(!empty($products->images))
                    @foreach($products->images as $pimage)
                        <div class="col-lg-1">
                            <img src="{{ asset('/img/products_image/'.$pimage->image) }}" height="80" width="80">
                            <a href="{{url('admin/products/image/'.$pimage->id)}}" class="btn btn-primary btn-danger btn-sm" data-method="get" data-trans-button-cancel="Cancel" data-trans-button-confirm="Delete" data-trans-title="Are you sure you want to do this?" style="cursor:pointer;" onclick="$(this).click();">
                                    <i data-toggle="tooltip" data-placement="top" title="" class="fa fa-trash" data-original-title="Delete"></i>
                                </a>
                            <!-- <a href="{{url('admin/products/image/'.$pimage->id)}}">
                                Delete
                            </a> -->
                        </div>
                    @endforeach  
                @endif 
            </div>    
            <!--form-group Prize image end-->

            <!--form-group-->
        </div>
        <!--col-->
    </div>
    <!--row-->
</div>
<!--card-body-->

@section('pagescript')


<script type="text/javascript">

$(document).ready(function() {
    $('#country-dropdown').on('change', function() {
        var business_name = this.value;
        $("#state-dropdown").html('');
        $.ajax({
            url: "{{ url('getcategory') }}",
            type: "get",
            data: {business_name: business_name
            },
            dataType : 'json',
            success: function(result){
                $('#state-dropdown').html('<option class="text-dark font-weight-bold" value="">Select Sub Category</option>'); 
                $.each(result.countries,function(key,value){
                    $("#state-dropdown").append('<option value="'+value.id+'" >'+value.service_name+'</option>');
                    });
            }
        });
    });    
});
</script>


<!--------------------------V Tiny MCE Text Editor Start ------------------------------------>
<script type="text/javascript">
    tinymce.init({
    selector: 'textarea.tinymce',
    height: 200,
    plugins: [
    'advlist autolink lists link image charmap print preview anchor',
    'searchreplace visualblocks code fullscreen',
    'insertdatetime media table paste imagetools wordcount'
    ],
    toolbar: 'insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
    content_style: 'body { font-family:Helvetica,Arial,sans-serif; font-size:14px }'
});
</script>    
<!--------------------------V Tiny MCE Text Editor End ------------------------------------->
@stop