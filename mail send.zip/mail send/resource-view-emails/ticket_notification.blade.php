<table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="box-sizing:border-box;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif,'Apple Color Emoji','Segoe UI Emoji','Segoe UI Symbol';background-color:#222a35;margin:0;padding:0 100px;width:100%">
    <tbody>
      <tr>
        <td align="center" style="">
          <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0;padding:0;width:100%">
            <tbody>
              <tr>
                <td style="padding:25px 0;text-align:center">
                  <a href="{{ config('app.url') }}" style="color:#ffffff;font-size:19px;font-weight:bold;text-decoration:none;display:inline-block"> <img src="{{ config('app.url') }}assets/images/cs_logo.png" alt="CleanSmart" height="120px" /> </a>
                </td>
              </tr>
              <tr>
                <td width="100%" cellpadding="0" cellspacing="0" style="">
                  <table align="center" cellpadding="0" cellspacing="0" role="presentation" style="color:#ffffff;">
                    <tbody>
                      <tr>
                        <td align="center" style="padding:42px">
                          <h1 style="font-size:32px;font-weight:normal;color:red;">Ticket Notification !</h1>
                          <p style="font-size:20px;line-height:1.5em;">Site: <b><br />
                          </p>
                          <p style="font-size:18px;line-height:1.5em;">You got red ticket notification from: <b>{{$userName}}</b> ({{$addedBy}}).<br /> About {{$task}}. <br/>Details are Below:<br/>{{$description}}
                          </p>
                          <p style="font-size:20px;line-height:1.5em;">
                            Thanking You !<br />
                          </p>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
            </tbody>
          </table>
        </td>
      </tr>
    </tbody>
</table>