<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.min.css" rel="stylesheet">


    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
	<style>
	    span.select2.select2-container.select2-container--classic{
	        width: 100% !important;
	    }
	</style>

	<title>Select 2</title>
</head>
<body>
	<div class="container">
		<div class="row justify-content-center">
        	<div class="col-md-8">
            	<div class="card mt-4">
					
					<div class="card-body">                    
                    <form class="w-px-500 p-3 p-md-3" action="" method="post" enctype="multipart/form-data">
                        @csrf
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label">Select 2 Example</label>
                            <div class="col-sm-9 mt-3">
                                <select class="js-example-basic-single" name="Framework">
                                    @foreach($students as $studentdata)
									  	<option value="{{$studentdata->name}}">{{$studentdata->name}}</option>
									@endforeach
                                </select>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label"></label>
                            <div class="col-sm-9">
                                <button type="submit" class="btn btn-success btn-block text-white">Submit</button>
                            </div>
                        </div>
                    </form>
                	</div>
				</div>	
			</div>
		</div>		
	</div>




<!-- <script>
$(document).ready(function() {
    $('.js-example-basic-single').select2();
});
</script -->>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
$(document).ready(function(){
    $('.js-example-basic-single').select2({
        theme: "classic"
    });
});
</script>

</body>
</html>